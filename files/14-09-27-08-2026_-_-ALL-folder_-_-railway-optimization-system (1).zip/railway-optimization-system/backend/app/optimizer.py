"""
AI Optimization Engine.

Algorithm: priority-weighted greedy constraint scheduler (a common, reliable
approach for real-time railway re-timetabling where a full MILP solve is too
slow to run interactively).

For each detected conflict:
  1. The two trains involved are ranked by an urgency score combining:
       - train priority (1 = highest, e.g. Superfast/Rajdhani-class)
       - train type weight (Superfast > Express > Passenger > Freight)
       - existing accumulated delay (a train already late is pushed less,
         to avoid compounding delay for passengers already affected)
  2. The lower-ranked (less urgent) train is shifted later by the minimum
     number of minutes required to clear the conflict plus the mandated
     safety headway (MIN_HEADWAY_MINUTES). This is the hard safety
     constraint and is never violated — trains are only ever delayed
     further to satisfy it, never advanced into an unsafe gap.
  3. The shift is re-checked against every other train sharing that
     resource, so a single change cannot silently create a new conflict
     downstream (cascading conflicts are resolved before moving on).
  4. Steps repeat until the conflict list for the network is empty or a
     safety iteration cap is hit (guards against pathological cycles).

Hard constraints (never relaxed): platform/track mutual exclusion, minimum
headway, station platform capacity.
Soft objectives (optimized): minimize total network delay, minimize number
of trains touched, maximize on-time punctuality.
"""
import datetime
from sqlalchemy.orm import Session

from . import models
from .conflicts import detect_conflicts, MIN_HEADWAY_MINUTES, _window, _overlaps

TRAIN_TYPE_WEIGHT = {
    models.TrainType.superfast: 5,
    models.TrainType.express: 4,
    models.TrainType.suburban: 3,
    models.TrainType.passenger: 2,
    models.TrainType.freight: 1,
}

ON_TIME_THRESHOLD_MINUTES = 5
MAX_ITERATIONS = 200


def _urgency(train: models.Train) -> float:
    priority_score = (6 - train.priority) * 10          # priority 1 -> 50, priority 5 -> 10
    type_score = TRAIN_TYPE_WEIGHT.get(train.train_type, 2) * 5
    delay_penalty = -0.5 * train.delay_minutes           # already-delayed trains lose some urgency
    return priority_score + type_score + delay_penalty


def _shift_train(train: models.Train, minutes: int):
    delta = datetime.timedelta(minutes=minutes)
    if train.estimated_arrival:
        train.estimated_arrival += delta
    if train.estimated_departure:
        train.estimated_departure += delta
    train.delay_minutes = max(0, train.delay_minutes + minutes)
    if train.delay_minutes <= ON_TIME_THRESHOLD_MINUTES:
        train.status = models.TrainStatus.on_time
    elif train.delay_minutes <= 30:
        train.status = models.TrainStatus.delayed
    else:
        train.status = models.TrainStatus.critical_delay


def _network_metrics(trains):
    total_delay = sum(t.delay_minutes for t in trains)
    on_time = sum(1 for t in trains if t.delay_minutes <= ON_TIME_THRESHOLD_MINUTES)
    punctuality = round(100.0 * on_time / len(trains), 1) if trains else 100.0
    return total_delay, punctuality


def run_optimization(db: Session, dry_run: bool = False) -> dict:
    trains = db.query(models.Train).filter(models.Train.is_cancelled.is_(False)).all()

    conflicts_before_objs = detect_conflicts(db, persist=True)
    conflicts_before = len(conflicts_before_objs)
    total_delay_before, punctuality_before = _network_metrics(trains)

    affected_train_ids = set()
    iterations = 0

    while iterations < MAX_ITERATIONS:
        current_conflicts = detect_conflicts(db, persist=False)
        # Only conflicts that actually require a time shift to resolve
        resolvable = [c for c in current_conflicts if c.train_b_id is not None]
        if not resolvable:
            break

        conflict = resolvable[0]
        train_a = db.query(models.Train).get(conflict.train_a_id)
        train_b = db.query(models.Train).get(conflict.train_b_id)
        if not train_a or not train_b:
            iterations += 1
            continue

        # The train with lower urgency yields
        yielding, holding = (train_a, train_b) if _urgency(train_a) < _urgency(train_b) else (train_b, train_a)

        wa, wb = _window(yielding), _window(holding)
        if wa and wb:
            # Minimum shift so the yielding train clears the holding train's
            # window plus the mandatory safety headway.
            required_gap = datetime.timedelta(minutes=MIN_HEADWAY_MINUTES)
            shift_minutes = int(((wb[1] + required_gap) - wa[0]).total_seconds() / 60)
            shift_minutes = max(shift_minutes, MIN_HEADWAY_MINUTES)
        else:
            shift_minutes = MIN_HEADWAY_MINUTES

        _shift_train(yielding, shift_minutes)
        affected_train_ids.add(yielding.id)
        db.flush()
        iterations += 1

    total_delay_after, punctuality_after = _network_metrics(trains)
    conflicts_after_objs = detect_conflicts(db, persist=True)
    conflicts_after = len(conflicts_after_objs)

    explanation = (
        f"Resolved conflicts by shifting {len(affected_train_ids)} lower-priority/lower-urgency "
        f"train(s) using a priority-weighted greedy scheduler. Urgency combines train priority "
        f"class, train type (Superfast > Express > Passenger > Freight) and existing delay, so "
        f"high-priority and already-late trains are protected first. Every shift enforces the "
        f"minimum {MIN_HEADWAY_MINUTES}-minute safety headway as a hard constraint — no train is "
        f"ever advanced into an unsafe gap, only delayed further when required. "
        f"Result: network delay {total_delay_before} -> {total_delay_after} minutes, "
        f"conflicts {conflicts_before} -> {conflicts_after}, "
        f"punctuality {punctuality_before}% -> {punctuality_after}%."
    )

    result = models.OptimizationResult(
        trains_affected=len(affected_train_ids),
        total_delay_before=total_delay_before,
        total_delay_after=total_delay_after,
        conflicts_before=conflicts_before,
        conflicts_after=conflicts_after,
        punctuality_before=punctuality_before,
        punctuality_after=punctuality_after,
        explanation=explanation,
        applied=not dry_run,
    )

    if dry_run:
        db.rollback()
    else:
        db.add(result)
        db.commit()
        db.refresh(result)

    return {
        "result": result,
        "trains_affected": list(affected_train_ids),
    }
