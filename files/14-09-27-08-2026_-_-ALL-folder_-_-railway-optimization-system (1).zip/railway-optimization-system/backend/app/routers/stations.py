from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import get_current_user

router = APIRouter(prefix="/api/stations", tags=["stations"])


def _detail(db: Session, station: models.Station) -> schemas.StationDetailOut:
    platforms = db.query(models.Platform).filter(models.Platform.station_id == station.id).all()
    available = sum(1 for p in platforms if not p.is_occupied and not p.under_maintenance)

    incoming = db.query(models.Train).filter(models.Train.next_station_id == station.id).count()
    outgoing = db.query(models.Train).filter(models.Train.current_station_id == station.id).count()

    trains_here = db.query(models.Train).filter(
        (models.Train.current_station_id == station.id) | (models.Train.next_station_id == station.id)
    ).all()
    avg_delay = round(sum(t.delay_minutes for t in trains_here) / len(trains_here), 1) if trains_here else 0.0

    occupancy_ratio = 1 - (available / station.platform_count) if station.platform_count else 0
    congestion = "High" if occupancy_ratio > 0.7 else "Moderate" if occupancy_ratio > 0.4 else "Low"

    tracks_touching = db.query(models.Track).filter(
        (models.Track.from_station_id == station.id) | (models.Track.to_station_id == station.id)
    ).all()
    track_util = round(
        100 * sum(1 for t in tracks_touching if t.congestion in ("Moderate", "High")) / len(tracks_touching), 1
    ) if tracks_touching else 0.0

    return schemas.StationDetailOut(
        id=station.id, code=station.code, name=station.name, zone=station.zone,
        latitude=station.latitude, longitude=station.longitude,
        platform_count=station.platform_count, state=station.state,
        available_platforms=available, incoming_trains=incoming, outgoing_trains=outgoing,
        congestion=congestion, track_utilization=track_util, average_delay=avg_delay,
    )


@router.get("", response_model=list[schemas.StationOut])
def list_stations(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(models.Station).all()


@router.get("/{code}", response_model=schemas.StationDetailOut)
def get_station(code: str, db: Session = Depends(get_db), _=Depends(get_current_user)):
    station = db.query(models.Station).filter(models.Station.code == code.upper()).first()
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")
    return _detail(db, station)


@router.get("/{code}/trains", response_model=list[schemas.TrainOut])
def station_trains(code: str, db: Session = Depends(get_db), _=Depends(get_current_user)):
    station = db.query(models.Station).filter(models.Station.code == code.upper()).first()
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")
    trains = db.query(models.Train).filter(
        (models.Train.current_station_id == station.id) | (models.Train.next_station_id == station.id)
    ).all()
    return trains
