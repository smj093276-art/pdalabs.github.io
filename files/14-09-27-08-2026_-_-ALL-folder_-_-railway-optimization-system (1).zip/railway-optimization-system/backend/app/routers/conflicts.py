from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import get_current_user
from ..conflicts import detect_conflicts

router = APIRouter(prefix="/api/conflicts", tags=["conflicts"])


@router.get("", response_model=list[schemas.ConflictOut])
def list_conflicts(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(models.Conflict).order_by(models.Conflict.detected_at.desc()).all()


@router.post("/scan", response_model=list[schemas.ConflictOut])
def scan_conflicts(db: Session = Depends(get_db), _=Depends(get_current_user)):
    """Re-run the real conflict detection engine against current train state."""
    return detect_conflicts(db, persist=True)


@router.post("/{conflict_id}/resolve")
def resolve_conflict(conflict_id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    conflict = db.query(models.Conflict).get(conflict_id)
    if conflict:
        conflict.resolved = True
        db.commit()
    return {"ok": True}
