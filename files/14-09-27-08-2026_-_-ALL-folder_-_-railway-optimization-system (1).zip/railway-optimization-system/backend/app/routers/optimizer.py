from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import get_current_user
from ..optimizer import run_optimization

router = APIRouter(prefix="/api/optimizer", tags=["optimizer"])


@router.get("/history", response_model=list[schemas.OptimizationResultOut])
def history(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(models.OptimizationResult).order_by(models.OptimizationResult.run_at.desc()).limit(20).all()


@router.post("/run", response_model=schemas.OptimizationResultOut)
def run(dry_run: bool = False, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    """Execute the real priority-weighted greedy scheduler against current
    train state. dry_run=True previews the result without persisting changes."""
    outcome = run_optimization(db, dry_run=dry_run)
    if not dry_run:
        db.add(models.AuditLog(username=user.username, action=f"RAN AI OPTIMIZATION (run #{outcome['result'].id})"))
        db.commit()
    return outcome["result"]
