import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import get_current_user
from ..conflicts import detect_conflicts

router = APIRouter(prefix="/api/simulation", tags=["simulation"])


@router.post("/run", response_model=schemas.SimulationResultOut)
def run_simulation(payload: schemas.SimulationRequest, db: Session = Depends(get_db),
                    user: models.User = Depends(get_current_user)):
    affected = []
    summary = ""

    if payload.scenario_type == "delay":
        train = db.query(models.Train).filter(models.Train.number == payload.train_number).first()
        if not train:
            raise HTTPException(status_code=404, detail="Train not found")
        minutes = payload.magnitude_minutes or 0
        delta = datetime.timedelta(minutes=minutes)
        if train.estimated_arrival:
            train.estimated_arrival += delta
        if train.estimated_departure:
            train.estimated_departure += delta
        train.delay_minutes += minutes
        train.status = (
            models.TrainStatus.on_time if train.delay_minutes <= 5 else
            models.TrainStatus.delayed if train.delay_minutes <= 30 else
            models.TrainStatus.critical_delay
        )
        affected.append(train.number)
        summary = f"Injected {minutes} min delay into {train.number} ({train.name})."

    elif payload.scenario_type == "track_block":
        track = db.query(models.Track).filter(models.Track.code == payload.track_code).first()
        if not track:
            raise HTTPException(status_code=404, detail="Track not found")
        track.is_blocked = True
        track.congestion = "High"
        trains_on_track = db.query(models.Train).filter(models.Train.track_id == track.id).all()
        for t in trains_on_track:
            bump = 30
            if t.estimated_arrival:
                t.estimated_arrival += datetime.timedelta(minutes=bump)
            if t.estimated_departure:
                t.estimated_departure += datetime.timedelta(minutes=bump)
            t.delay_minutes += bump
            t.status = models.TrainStatus.critical_delay
            affected.append(t.number)
        summary = f"Blocked track {track.code}; {len(affected)} train(s) rerouted/delayed."

    elif payload.scenario_type == "platform_unavailable":
        station = db.query(models.Station).filter(models.Station.code == payload.station_code).first()
        if not station:
            raise HTTPException(status_code=404, detail="Station not found")
        platforms = db.query(models.Platform).filter(models.Platform.station_id == station.id).all()
        if not platforms:
            raise HTTPException(status_code=400, detail="Station has no platforms")
        # take one platform out of service
        target = next((p for p in platforms if not p.under_maintenance), platforms[0])
        target.under_maintenance = True
        trains_here = db.query(models.Train).filter(
            (models.Train.current_station_id == station.id) & (models.Train.platform_id == target.id)
        ).all()
        for t in trains_here:
            # reassign to another free platform if possible, else delay
            alt = next((p for p in platforms if p.id != target.id and not p.is_occupied and not p.under_maintenance), None)
            if alt:
                alt.is_occupied = True
                alt.occupied_by_train_id = t.id
                t.platform_id = alt.id
            else:
                t.delay_minutes += 20
                if t.estimated_arrival:
                    t.estimated_arrival += datetime.timedelta(minutes=20)
                t.status = models.TrainStatus.delayed
            affected.append(t.number)
        summary = f"Platform {target.number} at {station.name} taken out of service; {len(affected)} train(s) affected."

    elif payload.scenario_type == "congestion":
        station = db.query(models.Station).filter(models.Station.code == payload.station_code).first()
        if not station:
            raise HTTPException(status_code=404, detail="Station not found")
        tracks = db.query(models.Track).filter(
            (models.Track.from_station_id == station.id) | (models.Track.to_station_id == station.id)
        ).all()
        for tr in tracks:
            tr.congestion = "High"
        trains_here = db.query(models.Train).filter(
            (models.Train.current_station_id == station.id) | (models.Train.next_station_id == station.id)
        ).all()
        for t in trains_here:
            bump = 15
            t.delay_minutes += bump
            if t.estimated_arrival:
                t.estimated_arrival += datetime.timedelta(minutes=bump)
            affected.append(t.number)
        summary = f"Simulated congestion surge at {station.name}; {len(affected)} train(s) delayed."

    elif payload.scenario_type == "cancellation":
        train = db.query(models.Train).filter(models.Train.number == payload.train_number).first()
        if not train:
            raise HTTPException(status_code=404, detail="Train not found")
        train.is_cancelled = True
        train.status = models.TrainStatus.cancelled
        if train.platform_id:
            platform = db.query(models.Platform).get(train.platform_id)
            if platform:
                platform.is_occupied = False
                platform.occupied_by_train_id = None
            train.platform_id = None
        affected.append(train.number)
        summary = f"Cancelled train {train.number} ({train.name}); its platform/track were freed."

    else:
        raise HTTPException(status_code=400, detail="Unknown scenario_type")

    scenario = models.SimulationScenario(
        name=f"{payload.scenario_type} scenario",
        scenario_type=payload.scenario_type,
        magnitude_minutes=payload.magnitude_minutes or 0,
        result_summary=summary,
    )
    db.add(scenario)
    db.add(models.AuditLog(username=user.username, action=f"RAN SIMULATION: {payload.scenario_type}"))
    db.commit()
    db.refresh(scenario)

    new_conflicts = detect_conflicts(db, persist=True)

    return schemas.SimulationResultOut(
        scenario_id=scenario.id,
        affected_trains=affected,
        new_conflicts=new_conflicts,
        summary=summary,
    )


@router.get("/history")
def simulation_history(db: Session = Depends(get_db), _=Depends(get_current_user)):
    scenarios = db.query(models.SimulationScenario).order_by(models.SimulationScenario.created_at.desc()).limit(20).all()
    return [
        {
            "id": s.id, "scenario_type": s.scenario_type, "created_at": s.created_at,
            "magnitude_minutes": s.magnitude_minutes, "result_summary": s.result_summary,
        }
        for s in scenarios
    ]
