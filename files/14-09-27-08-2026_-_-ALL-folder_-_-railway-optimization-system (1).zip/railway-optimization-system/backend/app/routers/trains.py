from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import get_current_user

router = APIRouter(prefix="/api/trains", tags=["trains"])


@router.get("", response_model=list[schemas.TrainOut])
def list_trains(status: str | None = None, db: Session = Depends(get_db), _=Depends(get_current_user)):
    q = db.query(models.Train)
    if status:
        q = q.filter(models.Train.status == status)
    return q.all()


@router.get("/{number}", response_model=schemas.TrainOut)
def get_train(number: str, db: Session = Depends(get_db), _=Depends(get_current_user)):
    train = db.query(models.Train).filter(models.Train.number == number).first()
    if not train:
        raise HTTPException(status_code=404, detail="Train not found")
    return train


@router.get("/{number}/route")
def get_train_route(number: str, db: Session = Depends(get_db), _=Depends(get_current_user)):
    train = db.query(models.Train).filter(models.Train.number == number).first()
    if not train:
        raise HTTPException(status_code=404, detail="Train not found")
    entries = db.query(models.ScheduleEntry).filter(models.ScheduleEntry.train_id == train.id).order_by(
        models.ScheduleEntry.sequence
    ).all()
    return [
        {
            "station_code": e.station.code,
            "station_name": e.station.name,
            "sequence": e.sequence,
            "original_arrival": e.original_arrival,
            "original_departure": e.original_departure,
            "optimized_arrival": e.optimized_arrival,
            "optimized_departure": e.optimized_departure,
            "platform_number": e.platform_number,
        }
        for e in entries
    ]
