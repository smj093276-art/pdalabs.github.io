from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import get_current_user

router = APIRouter(prefix="/api", tags=["tracks-platforms"])


@router.get("/tracks", response_model=list[schemas.TrackOut])
def list_tracks(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(models.Track).all()


@router.get("/tracks/{code}", response_model=schemas.TrackOut)
def get_track(code: str, db: Session = Depends(get_db), _=Depends(get_current_user)):
    track = db.query(models.Track).filter(models.Track.code == code.upper()).first()
    if not track:
        raise HTTPException(status_code=404, detail="Track not found")
    return track


@router.get("/platforms")
def list_platforms(station_code: str | None = None, db: Session = Depends(get_db), _=Depends(get_current_user)):
    q = db.query(models.Platform)
    if station_code:
        station = db.query(models.Station).filter(models.Station.code == station_code.upper()).first()
        if not station:
            raise HTTPException(status_code=404, detail="Station not found")
        q = q.filter(models.Platform.station_id == station.id)
    platforms = q.all()
    return [
        {
            "id": p.id,
            "station_code": p.station.code,
            "number": p.number,
            "is_occupied": p.is_occupied,
            "occupied_by_train_id": p.occupied_by_train_id,
            "under_maintenance": p.under_maintenance,
        }
        for p in platforms
    ]
