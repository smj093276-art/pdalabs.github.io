from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import get_current_user

router = APIRouter(prefix="/api", tags=["analytics"])


def _compute_summary(db: Session) -> schemas.DashboardSummary:
    trains = db.query(models.Train).filter(models.Train.is_cancelled.is_(False)).all()
    active_trains = len(trains)
    delayed = sum(1 for t in trains if t.delay_minutes > 5)
    conflicts = db.query(models.Conflict).filter(models.Conflict.resolved.is_(False)).count()
    critical_alerts = db.query(models.Conflict).filter(
        models.Conflict.resolved.is_(False), models.Conflict.severity == models.ConflictSeverity.critical
    ).count()

    platforms = db.query(models.Platform).all()
    platform_util = round(100 * sum(1 for p in platforms if p.is_occupied) / len(platforms), 1) if platforms else 0.0

    tracks = db.query(models.Track).all()
    track_util = round(
        100 * sum(1 for t in tracks if t.congestion in ("Moderate", "High")) / len(tracks), 1
    ) if tracks else 0.0

    on_time = sum(1 for t in trains if t.delay_minutes <= 5)
    punctuality = round(100 * on_time / active_trains, 1) if active_trains else 100.0

    return schemas.DashboardSummary(
        active_trains=active_trains, delayed_trains=delayed, active_conflicts=conflicts,
        platform_utilization=platform_util, track_utilization=track_util,
        network_punctuality=punctuality, critical_alerts=critical_alerts,
    )


@router.get("/dashboard/summary", response_model=schemas.DashboardSummary)
def dashboard_summary(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _compute_summary(db)


@router.get("/dashboard/alerts")
def dashboard_alerts(db: Session = Depends(get_db), _=Depends(get_current_user)):
    notifications = db.query(models.Notification).order_by(models.Notification.created_at.desc()).limit(10).all()
    return [
        {"id": n.id, "level": n.level, "message": n.message, "created_at": n.created_at, "read": n.read}
        for n in notifications
    ]


@router.get("/analytics/overview")
def analytics_overview(db: Session = Depends(get_db), _=Depends(get_current_user)):
    trains = db.query(models.Train).filter(models.Train.is_cancelled.is_(False)).all()
    summary = _compute_summary(db)

    by_type = {}
    for t in trains:
        key = t.train_type.value
        by_type.setdefault(key, {"count": 0, "total_delay": 0})
        by_type[key]["count"] += 1
        by_type[key]["total_delay"] += t.delay_minutes

    delay_buckets = {"On Time (<=5m)": 0, "Minor (6-30m)": 0, "Major (>30m)": 0}
    for t in trains:
        if t.delay_minutes <= 5:
            delay_buckets["On Time (<=5m)"] += 1
        elif t.delay_minutes <= 30:
            delay_buckets["Minor (6-30m)"] += 1
        else:
            delay_buckets["Major (>30m)"] += 1

    optimization_runs = db.query(models.OptimizationResult).order_by(models.OptimizationResult.run_at).all()
    trend = [
        {
            "run": i + 1,
            "delay_before": r.total_delay_before,
            "delay_after": r.total_delay_after,
            "punctuality_after": r.punctuality_after,
        }
        for i, r in enumerate(optimization_runs)
    ]

    top_delayed = sorted(trains, key=lambda t: t.delay_minutes, reverse=True)[:5]

    return {
        "summary": summary,
        "by_train_type": by_type,
        "delay_distribution": delay_buckets,
        "optimization_trend": trend,
        "top_delayed_trains": [
            {"number": t.number, "name": t.name, "delay_minutes": t.delay_minutes} for t in top_delayed
        ],
    }
