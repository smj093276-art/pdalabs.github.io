from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models
from ..database import get_db
from ..auth import get_current_user

router = APIRouter(prefix="/api/schedules", tags=["schedules"])


@router.get("")
def list_schedules(db: Session = Depends(get_db), _=Depends(get_current_user)):
    trains = db.query(models.Train).order_by(models.Train.scheduled_arrival).all()
    out = []
    for t in trains:
        out.append({
            "train_number": t.number,
            "train_name": t.name,
            "origin": t.origin.code,
            "destination": t.destination.code,
            "original_arrival": t.scheduled_arrival,
            "original_departure": t.scheduled_departure,
            "optimized_arrival": t.estimated_arrival,
            "optimized_departure": t.estimated_departure,
            "platform": t.platform_id,
            "delay_minutes": t.delay_minutes,
            "status": t.status.value,
        })
    return out
