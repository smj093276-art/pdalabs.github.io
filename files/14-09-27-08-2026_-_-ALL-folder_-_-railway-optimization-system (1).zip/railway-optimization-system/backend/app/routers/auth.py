from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import verify_password, hash_password, create_access_token, get_current_user

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=schemas.TokenResponse)
def login(payload: schemas.LoginRequest, request: Request, db: Session = Depends(get_db)):
    if not payload.username or not payload.password:
        raise HTTPException(status_code=400, detail="Username and password are required")

    user = db.query(models.User).filter(models.User.username == payload.username).first()

    # Hidden admin credentials: SAMPATHRAJ / 128 (seeded). Any other non-empty
    # username/password pair is auto-provisioned as a regular user, matching
    # the spec ("any non-empty username/password" logs a normal user in).
    if user is None:
        user = models.User(
            username=payload.username,
            hashed_password=hash_password(payload.password),
            role=models.Role.user,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    else:
        if user.role == models.Role.admin:
            # Admin account requires the exact seeded password.
            if not verify_password(payload.password, user.hashed_password):
                raise HTTPException(status_code=401, detail="Invalid credentials")
        # Regular users: any password is accepted for repeat logins too,
        # to match "any non-empty username / any non-empty password".

    db.add(models.AuditLog(
        username=user.username, action="LOGIN",
        ip_address=request.client.host if request.client else "",
    ))
    db.commit()

    token = create_access_token(user.username, user.role.value)
    return schemas.TokenResponse(access_token=token, role=user.role.value, username=user.username)


@router.get("/me")
def me(current_user: models.User = Depends(get_current_user)):
    return {"username": current_user.username, "role": current_user.role.value}
