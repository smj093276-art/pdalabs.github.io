from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..auth import require_admin

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/stats", response_model=schemas.AdminStats)
def stats(db: Session = Depends(get_db), _=Depends(require_admin)):
    return schemas.AdminStats(
        total_stations=db.query(models.Station).count(),
        total_trains=db.query(models.Train).count(),
        total_tracks=db.query(models.Track).count(),
        total_platforms=db.query(models.Platform).count(),
        active_users=db.query(models.User).filter(models.User.is_active.is_(True)).count(),
        optimization_runs=db.query(models.OptimizationResult).count(),
        active_simulations=db.query(models.SimulationScenario).count(),
        system_alerts=db.query(models.Conflict).filter(models.Conflict.resolved.is_(False)).count(),
    )


@router.get("/stations", response_model=list[schemas.StationOut])
def admin_list_stations(db: Session = Depends(get_db), _=Depends(require_admin)):
    return db.query(models.Station).all()


@router.post("/stations", response_model=schemas.StationOut)
def admin_create_station(payload: schemas.StationCreate, db: Session = Depends(get_db), _=Depends(require_admin)):
    if db.query(models.Station).filter(models.Station.code == payload.code.upper()).first():
        raise HTTPException(status_code=400, detail="Station code already exists")
    station = models.Station(
        code=payload.code.upper(), name=payload.name, zone=payload.zone,
        latitude=payload.latitude, longitude=payload.longitude,
        platform_count=payload.platform_count, state=payload.state,
    )
    db.add(station)
    db.flush()
    for p in range(1, payload.platform_count + 1):
        db.add(models.Platform(station_id=station.id, number=p))
    db.commit()
    db.refresh(station)
    return station


@router.delete("/stations/{station_id}")
def admin_delete_station(station_id: int, db: Session = Depends(get_db), _=Depends(require_admin)):
    station = db.query(models.Station).get(station_id)
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")
    db.delete(station)
    db.commit()
    return {"ok": True}


@router.get("/trains", response_model=list[schemas.TrainOut])
def admin_list_trains(db: Session = Depends(get_db), _=Depends(require_admin)):
    return db.query(models.Train).all()


@router.post("/trains", response_model=schemas.TrainOut)
def admin_create_train(payload: schemas.TrainCreate, db: Session = Depends(get_db), _=Depends(require_admin)):
    if db.query(models.Train).filter(models.Train.number == payload.number).first():
        raise HTTPException(status_code=400, detail="Train number already exists")
    origin = db.query(models.Station).get(payload.origin_id)
    dest = db.query(models.Station).get(payload.destination_id)
    if not origin or not dest:
        raise HTTPException(status_code=400, detail="Invalid origin/destination station id")
    train = models.Train(
        number=payload.number, name=payload.name,
        train_type=models.TrainType(payload.train_type), priority=payload.priority,
        origin_id=origin.id, destination_id=dest.id,
        current_station_id=origin.id, next_station_id=dest.id,
    )
    db.add(train)
    db.commit()
    db.refresh(train)
    return train


@router.delete("/trains/{train_id}")
def admin_delete_train(train_id: int, db: Session = Depends(get_db), _=Depends(require_admin)):
    train = db.query(models.Train).get(train_id)
    if not train:
        raise HTTPException(status_code=404, detail="Train not found")
    db.delete(train)
    db.commit()
    return {"ok": True}


@router.get("/users")
def admin_list_users(db: Session = Depends(get_db), _=Depends(require_admin)):
    users = db.query(models.User).all()
    return [
        {"id": u.id, "username": u.username, "role": u.role.value, "is_active": u.is_active,
         "created_at": u.created_at}
        for u in users
    ]


@router.post("/users/{user_id}/toggle-active")
def admin_toggle_user(user_id: int, db: Session = Depends(get_db), _=Depends(require_admin)):
    user = db.query(models.User).get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_active = not user.is_active
    db.commit()
    return {"ok": True, "is_active": user.is_active}


@router.get("/audit-logs", response_model=list[schemas.AuditLogOut])
def admin_audit_logs(db: Session = Depends(get_db), _=Depends(require_admin)):
    return db.query(models.AuditLog).order_by(models.AuditLog.created_at.desc()).limit(200).all()


@router.post("/tracks/{track_id}/toggle-block")
def admin_toggle_track(track_id: int, db: Session = Depends(get_db), _=Depends(require_admin)):
    track = db.query(models.Track).get(track_id)
    if not track:
        raise HTTPException(status_code=404, detail="Track not found")
    track.is_blocked = not track.is_blocked
    db.commit()
    return {"ok": True, "is_blocked": track.is_blocked}
