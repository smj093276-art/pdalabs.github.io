"""
Database configuration.

Uses SQLite by default (zero-config, ships working out of the box).
To use PostgreSQL instead (as originally specified), just set the
DATABASE_URL environment variable, e.g.:

    export DATABASE_URL="postgresql+psycopg2://user:password@localhost:5432/railway_db"

No other code changes are required — SQLAlchemy abstracts the dialect.
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./railway.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
