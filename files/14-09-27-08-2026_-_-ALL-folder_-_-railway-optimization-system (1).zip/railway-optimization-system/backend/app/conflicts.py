"""
Conflict detection engine.

Scans live train state and detects genuine conflicts by comparing
actual scheduled/estimated times, shared resources (tracks, platforms)
and station capacity — nothing here is hardcoded.

Rules implemented:
  1. Track conflict     -> two trains assigned the same track with overlapping
                            time windows (accounting for a minimum safe headway).
  2. Platform conflict   -> two trains assigned the same platform at the same
                            station with overlapping dwell windows.
  3. Schedule overlap    -> two trains at the same station whose arrival/departure
                            windows overlap regardless of platform assignment.
  4. Insufficient headway-> two trains on the same track moving in sequence with
                            less than MIN_HEADWAY_MINUTES between them.
  5. Station capacity    -> more trains scheduled at a station in a given window
                            than the station has platforms for.
"""
import datetime
from itertools import combinations
from sqlalchemy.orm import Session

from . import models

MIN_HEADWAY_MINUTES = 7  # minimum safe separation between trains on the same track


def _window(train: models.Train):
    """Return the (arrival, departure) estimated time window for a train, filling
    in sane fallbacks when a field is missing so comparisons never crash."""
    arr = train.estimated_arrival or train.scheduled_arrival
    dep = train.estimated_departure or train.scheduled_departure or arr
    if arr is None and dep is None:
        return None
    if arr is None:
        arr = dep
    if dep is None:
        dep = arr
    return arr, dep


def _overlaps(a_start, a_end, b_start, b_end, buffer_minutes=0):
    buf = datetime.timedelta(minutes=buffer_minutes)
    return a_start - buf < b_end and b_start - buf < a_end


def detect_conflicts(db: Session, persist: bool = True):
    """Run the full conflict scan. Returns list of newly detected Conflict ORM
    objects (not yet committed unless persist=True)."""
    trains = (
        db.query(models.Train)
        .filter(models.Train.is_cancelled.is_(False))
        .all()
    )
    found = []

    # --- 1 & 4: Track conflicts + headway violations ---
    by_track = {}
    for t in trains:
        if t.track_id:
            by_track.setdefault(t.track_id, []).append(t)

    for track_id, group in by_track.items():
        for a, b in combinations(group, 2):
            wa, wb = _window(a), _window(b)
            if not wa or not wb:
                continue
            if _overlaps(wa[0], wa[1], wb[0], wb[1]):
                found.append(_make(
                    models.ConflictType.track, models.ConflictSeverity.critical,
                    a, b, track_id=track_id,
                    desc=f"Trains {a.number} and {b.number} are both assigned track "
                         f"{track_id} with overlapping time windows."
                ))
            else:
                gap = min(abs((wa[0] - wb[1]).total_seconds()), abs((wb[0] - wa[1]).total_seconds())) / 60
                if gap < MIN_HEADWAY_MINUTES:
                    found.append(_make(
                        models.ConflictType.headway, models.ConflictSeverity.warning,
                        a, b, track_id=track_id,
                        desc=f"Trains {a.number} and {b.number} share track {track_id} "
                             f"with only {gap:.0f} min separation (min safe headway is "
                             f"{MIN_HEADWAY_MINUTES} min)."
                    ))

    # --- 2 & 3: Platform conflicts + station schedule overlaps ---
    by_station = {}
    for t in trains:
        sid = t.current_station_id or t.next_station_id
        if sid:
            by_station.setdefault(sid, []).append(t)

    for station_id, group in by_station.items():
        station = db.query(models.Station).get(station_id)
        for a, b in combinations(group, 2):
            wa, wb = _window(a), _window(b)
            if not wa or not wb:
                continue
            if _overlaps(wa[0], wa[1], wb[0], wb[1]):
                if a.platform_id and a.platform_id == b.platform_id:
                    found.append(_make(
                        models.ConflictType.platform, models.ConflictSeverity.critical,
                        a, b, station_id=station_id,
                        desc=f"Trains {a.number} and {b.number} are both assigned "
                             f"platform {a.platform_id} at {station.name if station else station_id} "
                             f"with overlapping dwell times."
                    ))
                else:
                    found.append(_make(
                        models.ConflictType.schedule_overlap, models.ConflictSeverity.warning,
                        a, b, station_id=station_id,
                        desc=f"Trains {a.number} and {b.number} have overlapping schedules "
                             f"at {station.name if station else station_id}."
                    ))

        # --- 5: Station capacity ---
        if station and len(group) > station.platform_count:
            found.append(_make(
                models.ConflictType.capacity, models.ConflictSeverity.warning,
                group[0], None, station_id=station_id,
                desc=f"{station.name}: {len(group)} trains scheduled against "
                     f"{station.platform_count} available platforms."
            ))

    if persist:
        # Clear previously auto-detected unresolved conflicts before writing the fresh scan,
        # so the conflict table always reflects current state rather than accumulating stale rows.
        db.query(models.Conflict).filter(models.Conflict.resolved.is_(False)).delete()
        db.add_all(found)
        db.commit()
        for c in found:
            db.refresh(c)

    return found


def _make(conflict_type, severity, train_a, train_b, station_id=None, track_id=None, desc=""):
    return models.Conflict(
        conflict_type=conflict_type,
        severity=severity,
        train_a_id=train_a.id,
        train_b_id=train_b.id if train_b else None,
        station_id=station_id,
        track_id=track_id,
        description=desc,
    )
