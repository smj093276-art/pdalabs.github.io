from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import Base, engine, SessionLocal
from .seed import seed_if_empty
from .routers import auth, stations, trains, infra, schedules, conflicts, optimizer, simulation, analytics, admin

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI-Based Railway Traffic Optimization & Scheduling System",
    description="Academic simulation platform — not a real railway control system.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(stations.router)
app.include_router(trains.router)
app.include_router(infra.router)
app.include_router(schedules.router)
app.include_router(conflicts.router)
app.include_router(optimizer.router)
app.include_router(simulation.router)
app.include_router(analytics.router)
app.include_router(admin.router)


@app.on_event("startup")
def startup():
    db = SessionLocal()
    try:
        seed_if_empty(db)
    finally:
        db.close()


@app.get("/api/health")
def health():
    return {"status": "SYSTEM OPERATIONAL"}
