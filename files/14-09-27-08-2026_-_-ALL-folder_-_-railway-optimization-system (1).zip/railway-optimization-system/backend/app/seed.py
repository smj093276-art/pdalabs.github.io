"""
Seeds the database with a realistic simulated Indian railway network.
Clearly a SIMULATION dataset — station layout mirrors the reference map,
but this is an academic project, not live railway data.
"""
import datetime
import random
from sqlalchemy.orm import Session

from . import models
from .auth import hash_password

random.seed(42)

STATIONS = [
    # code, name, zone, lat, lon, platforms, state
    ("NDLS", "New Delhi", "Northern Railway", 28.6435, 77.2197, 16, "Delhi"),
    ("CDG", "Chandigarh", "Northern Railway", 30.7333, 76.7794, 6, "Chandigarh"),
    ("LDH", "Ludhiana Jn", "Northern Railway", 30.9010, 75.8573, 7, "Punjab"),
    ("UMB", "Ambala Cantt", "Northern Railway", 30.3398, 76.8567, 8, "Haryana"),
    ("DDN", "Dehradun", "Northern Railway", 30.3165, 78.0322, 5, "Uttarakhand"),
    ("JU", "Jodhpur Jn", "North Western Railway", 26.2870, 73.0234, 8, "Rajasthan"),
    ("BKN", "Bikaner Jn", "North Western Railway", 28.0026, 73.3119, 6, "Rajasthan"),
    ("JP", "Jaipur Jn", "North Western Railway", 26.9196, 75.7878, 7, "Rajasthan"),
    ("LKO", "Lucknow NR", "Northern Railway", 26.8309, 80.9126, 9, "Uttar Pradesh"),
    ("GHY", "Guwahati", "Northeast Frontier Railway", 26.1794, 91.7481, 6, "Assam"),
    ("ADI", "Ahmedabad Jn", "Western Railway", 23.0272, 72.6013, 12, "Gujarat"),
    ("BPL", "Bhopal Jn", "West Central Railway", 23.2678, 77.4020, 6, "Madhya Pradesh"),
    ("BSB", "Varanasi Jn", "North Eastern Railway", 25.3282, 82.9878, 9, "Uttar Pradesh"),
    ("PNBE", "Patna Jn", "East Central Railway", 25.6093, 85.1414, 10, "Bihar"),
    ("BDTS", "Vadodara Jn", "Western Railway", 22.3072, 73.1812, 6, "Gujarat"),
    ("ST", "Surat", "Western Railway", 21.1959, 72.8302, 5, "Gujarat"),
    ("NGP", "Nagpur Jn", "Central Railway", 21.1458, 79.0882, 8, "Maharashtra"),
    ("R", "Raipur Jn", "South East Central Railway", 21.2514, 81.6296, 6, "Chhattisgarh"),
    ("BBS", "Bhubaneswar", "East Coast Railway", 20.2961, 85.8245, 6, "Odisha"),
    ("CSMT", "Mumbai CSMT", "Central Railway", 18.9398, 72.8355, 18, "Maharashtra"),
    ("UBL", "Hubballi Jn", "South Western Railway", 15.3468, 75.1240, 6, "Karnataka"),
    ("BZA", "Vijayawada Jn", "South Central Railway", 16.5062, 80.6480, 10, "Andhra Pradesh"),
    ("MAS", "Chennai Central", "Southern Railway", 13.0827, 80.2707, 12, "Tamil Nadu"),
    ("SBC", "Bengaluru City Jn", "South Western Railway", 12.9716, 77.5946, 10, "Karnataka"),
    ("MYS", "Mysuru Jn", "South Western Railway", 12.3052, 76.6552, 5, "Karnataka"),
    ("TVC", "Thiruvananthapuram Central", "Southern Railway", 8.4875, 76.9525, 6, "Kerala"),
    ("HWH", "Kolkata Howrah Jn", "Eastern Railway", 22.5834, 88.3419, 23, "West Bengal"),
    ("JBP", "Jabalpur Jn", "West Central Railway", 23.1685, 79.9331, 7, "Madhya Pradesh"),
    ("GAYA", "Gaya Jn", "East Central Railway", 24.7955, 84.9994, 6, "Bihar"),
]

# Simulated route network connecting the stations above (undirected pairs -> tracks in both directions)
ROUTE_PAIRS = [
    ("NDLS", "UMB"), ("UMB", "LDH"), ("LDH", "CDG"), ("UMB", "DDN"),
    ("NDLS", "JP"), ("JP", "JU"), ("JU", "BKN"), ("NDLS", "LKO"),
    ("LKO", "BSB"), ("BSB", "PNBE"), ("PNBE", "GAYA"), ("GAYA", "HWH"),
    ("PNBE", "HWH"), ("NDLS", "BPL"), ("BPL", "JBP"), ("JBP", "NGP"),
    ("BPL", "ADI"), ("ADI", "BDTS"), ("BDTS", "ST"), ("ST", "CSMT"),
    ("NGP", "CSMT"), ("NGP", "R"), ("R", "BBS"), ("BBS", "HWH"),
    ("NGP", "BZA"), ("BZA", "MAS"), ("MAS", "SBC"), ("SBC", "MYS"),
    ("SBC", "UBL"), ("UBL", "CSMT"), ("MAS", "TVC"), ("SBC", "TVC"),
    ("LKO", "GHY"), ("HWH", "GHY"),
]

TRAIN_TEMPLATES = [
    # number, name, type, priority, origin, destination
    ("12301", "Howrah Rajdhani Express", "Superfast", 1, "HWH", "NDLS"),
    ("12951", "Mumbai Rajdhani Express", "Superfast", 1, "CSMT", "NDLS"),
    ("12621", "Tamil Nadu Express", "Superfast", 1, "MAS", "NDLS"),
    ("12810", "Howrah Mumbai Mail", "Express", 2, "HWH", "CSMT"),
    ("12610", "Chennai Mail", "Express", 2, "MAS", "SBC"),
    ("12137", "Punjab Mail", "Express", 2, "CSMT", "UMB"),
    ("12723", "Andhra Pradesh Express", "Superfast", 2, "MAS", "NDLS"),
    ("22691", "Rajdhani Express", "Superfast", 1, "SBC", "NDLS"),
    ("12903", "Golden Temple Mail", "Express", 2, "CSMT", "UMB"),
    ("11077", "Jhelum Express", "Express", 3, "PNBE", "UMB"),
    ("12141", "Patna Express", "Express", 3, "PNBE", "CSMT"),
    ("15911", "Avadh Assam Express", "Express", 3, "NDLS", "GHY"),
    ("12833", "Howrah Ahmedabad Express", "Superfast", 2, "HWH", "ADI"),
    ("58501", "Jabalpur Passenger", "Passenger", 4, "JBP", "NGP"),
    ("59391", "Ratlam Passenger", "Passenger", 5, "BPL", "ADI"),
    ("12245", "Duronto Express", "Superfast", 1, "SBC", "HWH"),
    ("22119", "Tejas Express", "Superfast", 1, "CSMT", "NGP"),
    ("16031", "Andaman Express", "Express", 3, "MAS", "JU"),
    ("50101", "Nagpur Freight", "Freight", 5, "NGP", "BZA"),
    ("50202", "Ahmedabad Freight", "Freight", 5, "ADI", "ST"),
    ("12395", "Gaya Rajdhani Special", "Superfast", 1, "GAYA", "NDLS"),
    ("17017", "Ratnagiri Express", "Express", 3, "CSMT", "UBL"),
    ("12649", "Sampark Kranti Express", "Superfast", 2, "SBC", "NDLS"),
    ("22625", "Chennai Central Superfast", "Superfast", 2, "MAS", "TVC"),
]

CONGESTION_LEVELS = ["Low", "Moderate", "High"]


def _station_map(db: Session):
    return {s.code: s for s in db.query(models.Station).all()}


def seed_if_empty(db: Session):
    if db.query(models.Station).count() > 0:
        return  # already seeded

    # --- Users ---
    demo_user = models.User(
        username="demo",
        hashed_password=hash_password("demo1234"),
        role=models.Role.user,
    )
    admin_user = models.User(
        username="SAMPATHRAJ",
        hashed_password=hash_password("128"),
        role=models.Role.admin,
    )
    db.add_all([demo_user, admin_user])

    # --- Stations + platforms ---
    stations = {}
    for code, name, zone, lat, lon, plat_count, state in STATIONS:
        st = models.Station(
            code=code, name=name, zone=zone, latitude=lat, longitude=lon,
            platform_count=plat_count, state=state,
        )
        db.add(st)
        db.flush()
        stations[code] = st
        for p in range(1, plat_count + 1):
            db.add(models.Platform(station_id=st.id, number=p))

    db.flush()

    # --- Tracks (bidirectional) ---
    tracks = {}
    for a, b in ROUTE_PAIRS:
        sa, sb = stations[a], stations[b]
        length = round(random.uniform(80, 650), 1)
        for code_suffix, from_s, to_s in ((f"{a}-{b}", sa, sb), (f"{b}-{a}", sb, sa)):
            trk = models.Track(
                code=f"TRK-{code_suffix}",
                from_station_id=from_s.id,
                to_station_id=to_s.id,
                length_km=length,
                max_speed_kmph=random.choice([80, 100, 110, 130, 160]),
                congestion=random.choice(CONGESTION_LEVELS),
            )
            db.add(trk)
            db.flush()
            tracks[code_suffix] = trk

    # --- Trains ---
    now = datetime.datetime.utcnow()
    for number, name, ttype, priority, origin_code, dest_code in TRAIN_TEMPLATES:
        origin = stations[origin_code]
        dest = stations[dest_code]

        # pick a plausible "current position": either origin, or a mid-route station if a direct track exists
        track_key = f"{origin_code}-{dest_code}"
        track = tracks.get(track_key)
        current_station = origin
        next_station = dest if track else None

        delay = random.choice([0, 0, 0, 5, 12, 18, 27, 45, 62])
        sched_arr = now + datetime.timedelta(hours=random.uniform(0.5, 10))
        sched_dep = sched_arr + datetime.timedelta(minutes=random.choice([5, 10, 15, 20]))
        est_arr = sched_arr + datetime.timedelta(minutes=delay)
        est_dep = sched_dep + datetime.timedelta(minutes=delay)

        status = (
            models.TrainStatus.on_time if delay <= 5 else
            models.TrainStatus.delayed if delay <= 30 else
            models.TrainStatus.critical_delay
        )

        # assign a platform at the current station
        free_platforms = db.query(models.Platform).filter(
            models.Platform.station_id == current_station.id,
            models.Platform.is_occupied.is_(False),
        ).all()
        platform = random.choice(free_platforms) if free_platforms else None
        if platform:
            platform.is_occupied = True

        train = models.Train(
            number=number, name=name,
            train_type=models.TrainType(ttype), priority=priority,
            origin_id=origin.id, destination_id=dest.id,
            current_station_id=current_station.id,
            next_station_id=next_station.id if next_station else dest.id,
            platform_id=platform.id if platform else None,
            track_id=track.id if track else None,
            scheduled_arrival=sched_arr, estimated_arrival=est_arr,
            scheduled_departure=sched_dep, estimated_departure=est_dep,
            delay_minutes=delay, status=status,
        )
        db.add(train)
        db.flush()
        if platform:
            platform.occupied_by_train_id = train.id

        # simple 2-leg schedule: origin -> destination
        db.add(models.ScheduleEntry(
            train_id=train.id, station_id=origin.id, sequence=1,
            original_arrival=sched_arr, original_departure=sched_dep,
            optimized_arrival=est_arr, optimized_departure=est_dep,
            platform_number=platform.number if platform else None,
        ))
        db.add(models.ScheduleEntry(
            train_id=train.id, station_id=dest.id, sequence=2,
            original_arrival=sched_arr + datetime.timedelta(hours=6),
            original_departure=None,
        ))

    # --- Notifications ---
    db.add_all([
        models.Notification(level="critical", message="Track conflict likely near Nagpur Jn — review AI Optimizer."),
        models.Notification(level="warning", message="High congestion detected on the Mumbai-Nagpur corridor."),
        models.Notification(level="info", message="AI optimization available for 3 active conflicts."),
    ])

    db.commit()
