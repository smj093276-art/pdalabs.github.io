import datetime
from typing import Optional, List
from pydantic import BaseModel


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    username: str


class StationOut(BaseModel):
    id: int
    code: str
    name: str
    zone: str
    latitude: float
    longitude: float
    platform_count: int
    state: str

    class Config:
        from_attributes = True


class StationDetailOut(StationOut):
    available_platforms: int
    incoming_trains: int
    outgoing_trains: int
    congestion: str
    track_utilization: float
    average_delay: float


class TrackOut(BaseModel):
    id: int
    code: str
    from_station_id: int
    to_station_id: int
    length_km: float
    max_speed_kmph: int
    is_blocked: bool
    congestion: str

    class Config:
        from_attributes = True


class TrainOut(BaseModel):
    id: int
    number: str
    name: str
    train_type: str
    priority: int
    origin_id: int
    destination_id: int
    current_station_id: Optional[int]
    next_station_id: Optional[int]
    platform_id: Optional[int]
    track_id: Optional[int]
    scheduled_arrival: Optional[datetime.datetime]
    estimated_arrival: Optional[datetime.datetime]
    scheduled_departure: Optional[datetime.datetime]
    estimated_departure: Optional[datetime.datetime]
    delay_minutes: int
    status: str
    is_cancelled: bool

    class Config:
        from_attributes = True


class ConflictOut(BaseModel):
    id: int
    conflict_type: str
    severity: str
    train_a_id: int
    train_b_id: Optional[int]
    station_id: Optional[int]
    track_id: Optional[int]
    description: str
    detected_at: datetime.datetime
    resolved: bool

    class Config:
        from_attributes = True


class OptimizationResultOut(BaseModel):
    id: int
    run_at: datetime.datetime
    trains_affected: int
    total_delay_before: int
    total_delay_after: int
    conflicts_before: int
    conflicts_after: int
    punctuality_before: float
    punctuality_after: float
    explanation: str
    applied: bool

    class Config:
        from_attributes = True


class SimulationRequest(BaseModel):
    scenario_type: str  # delay | track_block | platform_unavailable | congestion | cancellation
    train_number: Optional[str] = None
    station_code: Optional[str] = None
    track_code: Optional[str] = None
    magnitude_minutes: Optional[int] = 0


class SimulationResultOut(BaseModel):
    scenario_id: int
    affected_trains: List[str]
    new_conflicts: List[ConflictOut]
    summary: str


class DashboardSummary(BaseModel):
    active_trains: int
    delayed_trains: int
    active_conflicts: int
    platform_utilization: float
    track_utilization: float
    network_punctuality: float
    critical_alerts: int


class AdminStats(BaseModel):
    total_stations: int
    total_trains: int
    total_tracks: int
    total_platforms: int
    active_users: int
    optimization_runs: int
    active_simulations: int
    system_alerts: int


class AuditLogOut(BaseModel):
    id: int
    username: str
    action: str
    ip_address: str
    created_at: datetime.datetime

    class Config:
        from_attributes = True


class TrainCreate(BaseModel):
    number: str
    name: str
    train_type: str
    priority: int = 3
    origin_id: int
    destination_id: int


class StationCreate(BaseModel):
    code: str
    name: str
    zone: str = ""
    latitude: float
    longitude: float
    platform_count: int = 4
    state: str = ""
