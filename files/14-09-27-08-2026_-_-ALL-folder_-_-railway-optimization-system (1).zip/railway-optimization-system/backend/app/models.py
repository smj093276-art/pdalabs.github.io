import enum
import datetime
from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, Enum
)
from sqlalchemy.orm import relationship
from .database import Base


def now():
    return datetime.datetime.utcnow()


class Role(str, enum.Enum):
    user = "user"
    admin = "admin"


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, index=True, nullable=False)
    hashed_password = Column(String(256), nullable=False)
    role = Column(Enum(Role), default=Role.user, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)


class Station(Base):
    __tablename__ = "stations"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(16), unique=True, index=True, nullable=False)
    name = Column(String(128), nullable=False)
    zone = Column(String(64), default="")
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    platform_count = Column(Integer, default=4)
    state = Column(String(64), default="")

    platforms = relationship("Platform", back_populates="station", cascade="all,delete-orphan")


class Platform(Base):
    __tablename__ = "platforms"
    id = Column(Integer, primary_key=True, index=True)
    station_id = Column(Integer, ForeignKey("stations.id"), nullable=False)
    number = Column(Integer, nullable=False)
    is_occupied = Column(Boolean, default=False)
    occupied_by_train_id = Column(Integer, ForeignKey("trains.id"), nullable=True)
    under_maintenance = Column(Boolean, default=False)

    station = relationship("Station", back_populates="platforms")


class Track(Base):
    __tablename__ = "tracks"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(32), unique=True, nullable=False)
    from_station_id = Column(Integer, ForeignKey("stations.id"), nullable=False)
    to_station_id = Column(Integer, ForeignKey("stations.id"), nullable=False)
    length_km = Column(Float, default=100.0)
    max_speed_kmph = Column(Integer, default=110)
    is_blocked = Column(Boolean, default=False)
    congestion = Column(String(16), default="Low")  # Low, Moderate, High

    from_station = relationship("Station", foreign_keys=[from_station_id])
    to_station = relationship("Station", foreign_keys=[to_station_id])


class TrainType(str, enum.Enum):
    superfast = "Superfast"
    express = "Express"
    passenger = "Passenger"
    freight = "Freight"
    suburban = "Suburban"


class TrainStatus(str, enum.Enum):
    on_time = "On Time"
    delayed = "Delayed"
    critical_delay = "Critical Delay"
    cancelled = "Cancelled"
    terminated = "Terminated"


class Train(Base):
    __tablename__ = "trains"
    id = Column(Integer, primary_key=True, index=True)
    number = Column(String(16), unique=True, index=True, nullable=False)
    name = Column(String(128), nullable=False)
    train_type = Column(Enum(TrainType), default=TrainType.express)
    priority = Column(Integer, default=3)  # 1 = highest priority, 5 = lowest

    origin_id = Column(Integer, ForeignKey("stations.id"), nullable=False)
    destination_id = Column(Integer, ForeignKey("stations.id"), nullable=False)
    current_station_id = Column(Integer, ForeignKey("stations.id"), nullable=True)
    next_station_id = Column(Integer, ForeignKey("stations.id"), nullable=True)

    platform_id = Column(Integer, ForeignKey("platforms.id"), nullable=True)
    track_id = Column(Integer, ForeignKey("tracks.id"), nullable=True)

    scheduled_arrival = Column(DateTime, nullable=True)
    estimated_arrival = Column(DateTime, nullable=True)
    scheduled_departure = Column(DateTime, nullable=True)
    estimated_departure = Column(DateTime, nullable=True)

    delay_minutes = Column(Integer, default=0)
    status = Column(Enum(TrainStatus), default=TrainStatus.on_time)
    is_cancelled = Column(Boolean, default=False)

    origin = relationship("Station", foreign_keys=[origin_id])
    destination = relationship("Station", foreign_keys=[destination_id])
    current_station = relationship("Station", foreign_keys=[current_station_id])
    next_station = relationship("Station", foreign_keys=[next_station_id])
    track = relationship("Track", foreign_keys=[track_id])


class ScheduleEntry(Base):
    __tablename__ = "schedules"
    id = Column(Integer, primary_key=True, index=True)
    train_id = Column(Integer, ForeignKey("trains.id"), nullable=False)
    station_id = Column(Integer, ForeignKey("stations.id"), nullable=False)
    sequence = Column(Integer, default=0)
    original_arrival = Column(DateTime, nullable=True)
    original_departure = Column(DateTime, nullable=True)
    optimized_arrival = Column(DateTime, nullable=True)
    optimized_departure = Column(DateTime, nullable=True)
    platform_number = Column(Integer, nullable=True)

    train = relationship("Train")
    station = relationship("Station")


class ConflictType(str, enum.Enum):
    track = "Track Conflict"
    platform = "Platform Conflict"
    schedule_overlap = "Schedule Overlap"
    headway = "Insufficient Headway"
    capacity = "Station Capacity Conflict"


class ConflictSeverity(str, enum.Enum):
    critical = "Critical"
    warning = "Warning"
    info = "Info"


class Conflict(Base):
    __tablename__ = "conflicts"
    id = Column(Integer, primary_key=True, index=True)
    conflict_type = Column(Enum(ConflictType), nullable=False)
    severity = Column(Enum(ConflictSeverity), default=ConflictSeverity.warning)
    train_a_id = Column(Integer, ForeignKey("trains.id"), nullable=False)
    train_b_id = Column(Integer, ForeignKey("trains.id"), nullable=True)
    station_id = Column(Integer, ForeignKey("stations.id"), nullable=True)
    track_id = Column(Integer, ForeignKey("tracks.id"), nullable=True)
    description = Column(Text, default="")
    detected_at = Column(DateTime, default=now)
    resolved = Column(Boolean, default=False)

    train_a = relationship("Train", foreign_keys=[train_a_id])
    train_b = relationship("Train", foreign_keys=[train_b_id])
    station = relationship("Station")
    track = relationship("Track")


class OptimizationResult(Base):
    __tablename__ = "optimization_results"
    id = Column(Integer, primary_key=True, index=True)
    run_at = Column(DateTime, default=now)
    trains_affected = Column(Integer, default=0)
    total_delay_before = Column(Integer, default=0)
    total_delay_after = Column(Integer, default=0)
    conflicts_before = Column(Integer, default=0)
    conflicts_after = Column(Integer, default=0)
    punctuality_before = Column(Float, default=0.0)
    punctuality_after = Column(Float, default=0.0)
    explanation = Column(Text, default="")
    applied = Column(Boolean, default=False)


class SimulationScenario(Base):
    __tablename__ = "simulation_scenarios"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(128), default="")
    scenario_type = Column(String(32), nullable=False)  # delay, track_block, platform_unavailable, congestion, cancellation
    target_train_id = Column(Integer, ForeignKey("trains.id"), nullable=True)
    target_station_id = Column(Integer, ForeignKey("stations.id"), nullable=True)
    target_track_id = Column(Integer, ForeignKey("tracks.id"), nullable=True)
    magnitude_minutes = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)
    result_summary = Column(Text, default="")


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True, index=True)
    level = Column(String(16), default="info")  # critical, warning, info
    message = Column(Text, nullable=False)
    created_at = Column(DateTime, default=now)
    read = Column(Boolean, default=False)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), nullable=False)
    action = Column(String(256), nullable=False)
    ip_address = Column(String(64), default="")
    created_at = Column(DateTime, default=now)
