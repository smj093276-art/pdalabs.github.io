/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        panel: "#0f1729",
        panel2: "#131c33",
        base: "#0a0f1e",
        border: "#1e293b",
        accent: "#3b82f6",
        accent2: "#06b6d4",
        ok: "#22c55e",
        warn: "#f59e0b",
        crit: "#ef4444",
        muted: "#64748b",
      },
      boxShadow: {
        card: "0 0 0 1px rgba(255,255,255,0.04), 0 8px 24px rgba(0,0,0,0.35)",
      },
    },
  },
  plugins: [],
}
