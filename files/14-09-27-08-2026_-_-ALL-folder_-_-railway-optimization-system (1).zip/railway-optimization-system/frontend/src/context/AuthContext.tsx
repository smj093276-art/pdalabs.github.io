import React, { createContext, useContext, useEffect, useState } from 'react'
import { api } from '../api/client'

interface AuthUser {
  username: string
  role: 'user' | 'admin'
}

interface AuthContextValue {
  user: AuthUser | null
  loading: boolean
  login: (username: string, password: string) => Promise<AuthUser>
  logout: () => void
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const stored = localStorage.getItem('railopt_user')
    const token = localStorage.getItem('railopt_token')
    if (stored && token) {
      setUser(JSON.parse(stored))
    }
    setLoading(false)
  }, [])

  async function login(username: string, password: string): Promise<AuthUser> {
    const res = await api.post('/auth/login', { username, password })
    const { access_token, role, username: uname } = res.data
    localStorage.setItem('railopt_token', access_token)
    const authUser: AuthUser = { username: uname, role }
    localStorage.setItem('railopt_user', JSON.stringify(authUser))
    setUser(authUser)
    return authUser
  }

  function logout() {
    localStorage.removeItem('railopt_token')
    localStorage.removeItem('railopt_user')
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
