export interface Station {
  id: number
  code: string
  name: string
  zone: string
  latitude: number
  longitude: number
  platform_count: number
  state: string
}

export interface StationDetail extends Station {
  available_platforms: number
  incoming_trains: number
  outgoing_trains: number
  congestion: string
  track_utilization: number
  average_delay: number
}

export interface Train {
  id: number
  number: string
  name: string
  train_type: string
  priority: number
  origin_id: number
  destination_id: number
  current_station_id: number | null
  next_station_id: number | null
  platform_id: number | null
  track_id: number | null
  scheduled_arrival: string | null
  estimated_arrival: string | null
  scheduled_departure: string | null
  estimated_departure: string | null
  delay_minutes: number
  status: string
  is_cancelled: boolean
}

export interface Conflict {
  id: number
  conflict_type: string
  severity: string
  train_a_id: number
  train_b_id: number | null
  station_id: number | null
  track_id: number | null
  description: string
  detected_at: string
  resolved: boolean
}

export interface OptimizationResult {
  id: number
  run_at: string
  trains_affected: number
  total_delay_before: number
  total_delay_after: number
  conflicts_before: number
  conflicts_after: number
  punctuality_before: number
  punctuality_after: number
  explanation: string
  applied: boolean
}

export interface DashboardSummary {
  active_trains: number
  delayed_trains: number
  active_conflicts: number
  platform_utilization: number
  track_utilization: number
  network_punctuality: number
  critical_alerts: number
}

export interface Track {
  id: number
  code: string
  from_station_id: number
  to_station_id: number
  length_km: number
  max_speed_kmph: number
  is_blocked: boolean
  congestion: string
}
