import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { ProtectedRoute } from './components/ProtectedRoute'

import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import LiveNetwork from './pages/LiveNetwork'
import Trains from './pages/Trains'
import Schedules from './pages/Schedules'
import Platforms from './pages/Platforms'
import Tracks from './pages/Tracks'
import Conflicts from './pages/Conflicts'
import AIOptimizer from './pages/AIOptimizer'
import Simulation from './pages/Simulation'
import Analytics from './pages/Analytics'
import Admin from './pages/Admin'

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/live-network" element={<ProtectedRoute><LiveNetwork /></ProtectedRoute>} />
          <Route path="/trains" element={<ProtectedRoute><Trains /></ProtectedRoute>} />
          <Route path="/schedules" element={<ProtectedRoute><Schedules /></ProtectedRoute>} />
          <Route path="/platforms" element={<ProtectedRoute><Platforms /></ProtectedRoute>} />
          <Route path="/tracks" element={<ProtectedRoute><Tracks /></ProtectedRoute>} />
          <Route path="/conflicts" element={<ProtectedRoute><Conflicts /></ProtectedRoute>} />
          <Route path="/optimizer" element={<ProtectedRoute><AIOptimizer /></ProtectedRoute>} />
          <Route path="/simulation" element={<ProtectedRoute><Simulation /></ProtectedRoute>} />
          <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
          <Route path="/admin" element={<ProtectedRoute adminOnly><Admin /></ProtectedRoute>} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  )
}
