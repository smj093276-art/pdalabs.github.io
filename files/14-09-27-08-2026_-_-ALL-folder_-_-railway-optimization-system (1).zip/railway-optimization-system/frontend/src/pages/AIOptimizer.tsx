import React, { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import { api } from '../api/client'
import { OptimizationResult } from '../types'

export default function AIOptimizer() {
  const [history, setHistory] = useState<OptimizationResult[]>([])
  const [latest, setLatest] = useState<OptimizationResult | null>(null)
  const [running, setRunning] = useState(false)

  async function load() {
    const res = await api.get('/optimizer/history')
    setHistory(res.data)
    if (res.data.length) setLatest(res.data[0])
  }
  useEffect(() => { load() }, [])

  async function run() {
    setRunning(true)
    try {
      const res = await api.post('/optimizer/run')
      setLatest(res.data)
      load()
    } finally {
      setRunning(false)
    }
  }

  const delayReduction = latest ? latest.total_delay_before - latest.total_delay_after : 0
  const conflictsAvoided = latest ? latest.conflicts_before - latest.conflicts_after : 0
  const punctualityGain = latest ? +(latest.punctuality_after - latest.punctuality_before).toFixed(1) : 0

  return (
    <Layout title="AI Optimizer" subtitle="Priority-weighted greedy constraint scheduler for conflict-free timetabling">
      <div className="flex justify-end mb-4">
        <button
          onClick={run} disabled={running}
          className="text-xs bg-accent hover:bg-accent/90 disabled:opacity-60 text-white rounded-lg px-4 py-2.5 font-medium"
        >
          {running ? 'Optimizing…' : 'Run Optimization'}
        </button>
      </div>

      {latest ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="card p-4">
              <h3 className="text-xs text-slate-500 mb-3">Total Network Delay</h3>
              <div className="flex items-end gap-3">
                <div>
                  <div className="text-[10px] text-slate-500">Before</div>
                  <div className="text-xl font-bold text-slate-300">{latest.total_delay_before}m</div>
                </div>
                <div className="text-slate-600">→</div>
                <div>
                  <div className="text-[10px] text-slate-500">After</div>
                  <div className="text-xl font-bold text-ok">{latest.total_delay_after}m</div>
                </div>
              </div>
              <div className="text-xs text-ok mt-2">-{delayReduction}m reduced</div>
            </div>

            <div className="card p-4">
              <h3 className="text-xs text-slate-500 mb-3">Conflicts</h3>
              <div className="flex items-end gap-3">
                <div>
                  <div className="text-[10px] text-slate-500">Before</div>
                  <div className="text-xl font-bold text-slate-300">{latest.conflicts_before}</div>
                </div>
                <div className="text-slate-600">→</div>
                <div>
                  <div className="text-[10px] text-slate-500">After</div>
                  <div className="text-xl font-bold text-ok">{latest.conflicts_after}</div>
                </div>
              </div>
              <div className="text-xs text-ok mt-2">{conflictsAvoided} avoided</div>
            </div>

            <div className="card p-4">
              <h3 className="text-xs text-slate-500 mb-3">Network Punctuality</h3>
              <div className="flex items-end gap-3">
                <div>
                  <div className="text-[10px] text-slate-500">Before</div>
                  <div className="text-xl font-bold text-slate-300">{latest.punctuality_before}%</div>
                </div>
                <div className="text-slate-600">→</div>
                <div>
                  <div className="text-[10px] text-slate-500">After</div>
                  <div className="text-xl font-bold text-ok">{latest.punctuality_after}%</div>
                </div>
              </div>
              <div className="text-xs text-ok mt-2">+{punctualityGain}% improvement</div>
            </div>
          </div>

          <div className="card p-5 mb-6">
            <h3 className="text-sm font-semibold text-slate-200 mb-2">Why this optimization was selected</h3>
            <p className="text-xs text-slate-400 leading-relaxed">{latest.explanation}</p>
            <p className="text-[11px] text-slate-600 mt-3">
              {latest.trains_affected} train(s) affected · run at {new Date(latest.run_at).toLocaleString()}
            </p>
          </div>
        </>
      ) : (
        <div className="card p-8 text-center text-xs text-slate-500 mb-6">
          No optimization has been run yet. Click "Run Optimization" to generate a schedule.
        </div>
      )}

      <h3 className="text-sm font-semibold text-slate-200 mb-3">Optimization History</h3>
      <div className="card overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-panel2 text-slate-500 text-left">
            <tr>
              <th className="px-3 py-2 font-medium">Run</th>
              <th className="px-3 py-2 font-medium">Trains Affected</th>
              <th className="px-3 py-2 font-medium">Delay Δ</th>
              <th className="px-3 py-2 font-medium">Conflicts Δ</th>
              <th className="px-3 py-2 font-medium">Punctuality</th>
            </tr>
          </thead>
          <tbody>
            {history.map((h) => (
              <tr key={h.id} className="border-t border-border">
                <td className="px-3 py-2 text-slate-400">{new Date(h.run_at).toLocaleString()}</td>
                <td className="px-3 py-2 text-slate-400">{h.trains_affected}</td>
                <td className="px-3 py-2 text-ok">-{h.total_delay_before - h.total_delay_after}m</td>
                <td className="px-3 py-2 text-ok">-{h.conflicts_before - h.conflicts_after}</td>
                <td className="px-3 py-2 text-slate-400">{h.punctuality_before}% → {h.punctuality_after}%</td>
              </tr>
            ))}
            {history.length === 0 && (
              <tr><td colSpan={5} className="px-3 py-6 text-center text-slate-500">No runs yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </Layout>
  )
}
