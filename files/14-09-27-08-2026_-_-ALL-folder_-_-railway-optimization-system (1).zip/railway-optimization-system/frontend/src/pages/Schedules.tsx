import React, { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import { api } from '../api/client'

interface ScheduleRow {
  train_number: string
  train_name: string
  origin: string
  destination: string
  original_arrival: string | null
  original_departure: string | null
  optimized_arrival: string | null
  optimized_departure: string | null
  platform: number | null
  delay_minutes: number
  status: string
}

function fmt(iso: string | null) {
  if (!iso) return '—'
  return new Date(iso).toLocaleString([], { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' })
}

export default function Schedules() {
  const [rows, setRows] = useState<ScheduleRow[]>([])
  const [mode, setMode] = useState<'original' | 'optimized'>('optimized')

  async function load() {
    const res = await api.get('/schedules')
    setRows(res.data)
  }
  useEffect(() => { load() }, [])

  function exportCsv() {
    const header = ['Train', 'Name', 'Origin', 'Destination', 'Arrival', 'Departure', 'Platform', 'Delay(min)', 'Status']
    const lines = rows.map((r) => [
      r.train_number, r.train_name, r.origin, r.destination,
      mode === 'optimized' ? fmt(r.optimized_arrival) : fmt(r.original_arrival),
      mode === 'optimized' ? fmt(r.optimized_departure) : fmt(r.original_departure),
      r.platform ?? '', r.delay_minutes, r.status,
    ])
    const csv = [header, ...lines].map((l) => l.join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'schedule.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <Layout title="Schedule Management" subtitle="Original vs AI-optimized schedule across the network">
      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-2">
          <button
            onClick={() => setMode('original')}
            className={`text-xs px-3 py-1.5 rounded-lg border ${mode === 'original' ? 'bg-accent/15 border-accent/40 text-accent' : 'bg-panel2 border-border text-slate-400'}`}
          >Original Schedule</button>
          <button
            onClick={() => setMode('optimized')}
            className={`text-xs px-3 py-1.5 rounded-lg border ${mode === 'optimized' ? 'bg-accent/15 border-accent/40 text-accent' : 'bg-panel2 border-border text-slate-400'}`}
          >Optimized Schedule</button>
        </div>
        <button onClick={exportCsv} className="text-xs bg-panel2 border border-border rounded-lg px-3 py-1.5 text-slate-300 hover:border-accent/40">Export CSV</button>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-panel2 text-slate-500 text-left">
            <tr>
              <th className="px-3 py-2 font-medium">Train</th>
              <th className="px-3 py-2 font-medium">Route</th>
              <th className="px-3 py-2 font-medium">Arrival</th>
              <th className="px-3 py-2 font-medium">Departure</th>
              <th className="px-3 py-2 font-medium">Platform</th>
              <th className="px-3 py-2 font-medium">Delay</th>
              <th className="px-3 py-2 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.train_number} className="border-t border-border hover:bg-panel2/60">
                <td className="px-3 py-2">
                  <div className="font-medium text-slate-200">{r.train_number}</div>
                  <div className="text-slate-500">{r.train_name}</div>
                </td>
                <td className="px-3 py-2 text-slate-400">{r.origin} → {r.destination}</td>
                <td className="px-3 py-2 text-slate-400">{fmt(mode === 'optimized' ? r.optimized_arrival : r.original_arrival)}</td>
                <td className="px-3 py-2 text-slate-400">{fmt(mode === 'optimized' ? r.optimized_departure : r.original_departure)}</td>
                <td className="px-3 py-2 text-slate-400">{r.platform ?? '—'}</td>
                <td className="px-3 py-2 text-slate-400">{r.delay_minutes}m</td>
                <td className="px-3 py-2">
                  <span className={`badge ${r.status === 'On Time' ? 'badge-ok' : r.status === 'Delayed' ? 'badge-warn' : r.status === 'Critical Delay' ? 'badge-crit' : 'badge-muted'}`}>{r.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  )
}
