import React, { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import { api } from '../api/client'
import { Track, Station } from '../types'

export default function Tracks() {
  const [tracks, setTracks] = useState<Track[]>([])
  const [stations, setStations] = useState<Record<number, Station>>({})

  async function load() {
    const [tr, st] = await Promise.all([api.get('/tracks'), api.get('/stations')])
    setTracks(tr.data)
    const map: Record<number, Station> = {}
    st.data.forEach((s: Station) => (map[s.id] = s))
    setStations(map)
  }
  useEffect(() => { load() }, [])

  return (
    <Layout title="Tracks" subtitle={`${tracks.length} simulated track segments across the network`}>
      <div className="card overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-panel2 text-slate-500 text-left">
            <tr>
              <th className="px-3 py-2 font-medium">Track</th>
              <th className="px-3 py-2 font-medium">From → To</th>
              <th className="px-3 py-2 font-medium">Length</th>
              <th className="px-3 py-2 font-medium">Max Speed</th>
              <th className="px-3 py-2 font-medium">Congestion</th>
              <th className="px-3 py-2 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {tracks.map((t) => (
              <tr key={t.id} className="border-t border-border hover:bg-panel2/60">
                <td className="px-3 py-2 text-slate-200 font-medium">{t.code}</td>
                <td className="px-3 py-2 text-slate-400">
                  {stations[t.from_station_id]?.code} → {stations[t.to_station_id]?.code}
                </td>
                <td className="px-3 py-2 text-slate-400">{t.length_km} km</td>
                <td className="px-3 py-2 text-slate-400">{t.max_speed_kmph} km/h</td>
                <td className="px-3 py-2">
                  <span className={`badge ${t.congestion === 'High' ? 'badge-crit' : t.congestion === 'Moderate' ? 'badge-warn' : 'badge-ok'}`}>{t.congestion}</span>
                </td>
                <td className="px-3 py-2">
                  {t.is_blocked ? <span className="badge badge-crit">Blocked</span> : <span className="badge badge-ok">Clear</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  )
}
