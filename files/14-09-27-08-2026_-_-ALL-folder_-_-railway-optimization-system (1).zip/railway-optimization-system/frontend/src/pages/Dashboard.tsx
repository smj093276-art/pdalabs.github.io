import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'
import KpiCard from '../components/KpiCard'
import RailwayMap from '../components/RailwayMap'
import { api } from '../api/client'
import { DashboardSummary, Station, Track, Train, Conflict } from '../types'

export default function Dashboard() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null)
  const [stations, setStations] = useState<Station[]>([])
  const [tracks, setTracks] = useState<Track[]>([])
  const [trains, setTrains] = useState<Train[]>([])
  const [conflicts, setConflicts] = useState<Conflict[]>([])
  const [alerts, setAlerts] = useState<any[]>([])
  const navigate = useNavigate()

  async function load() {
    const [s, st, tr, tn, cf, al] = await Promise.all([
      api.get('/dashboard/summary'),
      api.get('/stations'),
      api.get('/tracks'),
      api.get('/trains'),
      api.get('/conflicts'),
      api.get('/dashboard/alerts'),
    ])
    setSummary(s.data)
    setStations(st.data)
    setTracks(tr.data)
    setTrains(tn.data)
    setConflicts(cf.data.filter((c: Conflict) => !c.resolved))
    setAlerts(al.data)
  }

  useEffect(() => {
    load()
    const id = setInterval(load, 15000)
    return () => clearInterval(id)
  }, [])

  return (
    <Layout title="Dashboard" subtitle="Network-wide overview of trains, conflicts and utilization">
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3 mb-6">
        <KpiCard label="Active Trains" value={summary?.active_trains ?? '—'} />
        <KpiCard label="Delayed Trains" value={summary?.delayed_trains ?? '—'} tone="warn" />
        <KpiCard label="Active Conflicts" value={summary?.active_conflicts ?? '—'} tone={summary && summary.active_conflicts > 0 ? 'crit' : 'ok'} />
        <KpiCard label="Platform Utilization" value={`${summary?.platform_utilization ?? '—'}%`} />
        <KpiCard label="Track Utilization" value={`${summary?.track_utilization ?? '—'}%`} />
        <KpiCard label="Network Punctuality" value={`${summary?.network_punctuality ?? '—'}%`} tone="ok" />
        <KpiCard label="Critical Alerts" value={summary?.critical_alerts ?? '—'} tone={summary && summary.critical_alerts > 0 ? 'crit' : 'ok'} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 card p-3 h-[480px]">
          <div className="flex items-center justify-between px-2 pb-2">
            <h2 className="text-sm font-semibold text-slate-200">Interactive Railway Network (Live Map)</h2>
            <button onClick={() => navigate('/live-network')} className="text-xs text-accent hover:underline">View All Trains →</button>
          </div>
          <div className="h-[420px]">
            <RailwayMap
              stations={stations} tracks={tracks} trains={trains}
              onSelectStation={(code) => navigate(`/live-network?station=${code}`)}
              onSelectTrain={(num) => navigate(`/live-network?train=${num}`)}
            />
          </div>
        </div>

        <div className="space-y-4">
          <div className="card p-4">
            <h2 className="text-sm font-semibold text-slate-200 mb-3">Active Alerts</h2>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {alerts.length === 0 && <div className="text-xs text-slate-500">No active alerts.</div>}
              {alerts.map((a) => (
                <div key={a.id} className={`text-xs rounded-lg px-3 py-2 border ${
                  a.level === 'critical' ? 'bg-crit/10 border-crit/30 text-crit' :
                  a.level === 'warning' ? 'bg-warn/10 border-warn/30 text-warn' :
                  'bg-accent/10 border-accent/30 text-accent'
                }`}>
                  <div className="font-semibold uppercase text-[10px] mb-0.5">{a.level}</div>
                  {a.message}
                </div>
              ))}
            </div>
          </div>

          <div className="card p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-200">AI Recommendation</h2>
              <button onClick={() => navigate('/optimizer')} className="text-xs text-accent hover:underline">Review →</button>
            </div>
            {conflicts.length > 0 ? (
              <p className="text-xs text-slate-400 leading-relaxed">
                {conflicts.length} active conflict{conflicts.length > 1 ? 's' : ''} detected across the network.
                Optimization is available — run the AI Optimizer to resolve them while protecting
                high-priority trains.
              </p>
            ) : (
              <p className="text-xs text-slate-500">No conflicts detected. Network is running clean.</p>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        <div className="card p-4">
          <h2 className="text-sm font-semibold text-slate-200 mb-3">Active Conflicts</h2>
          <div className="space-y-2 max-h-56 overflow-y-auto">
            {conflicts.length === 0 && <div className="text-xs text-slate-500">None right now.</div>}
            {conflicts.slice(0, 6).map((c) => (
              <div key={c.id} className="flex items-center justify-between text-xs bg-panel2 rounded-lg px-3 py-2 border border-border">
                <div>
                  <span className={`badge ${c.severity === 'Critical' ? 'badge-crit' : 'badge-warn'} mr-2`}>{c.severity}</span>
                  {c.conflict_type}
                </div>
                <button onClick={() => navigate('/conflicts')} className="text-accent hover:underline">View</button>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-4">
          <h2 className="text-sm font-semibold text-slate-200 mb-3">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => navigate('/optimizer')} className="text-xs bg-accent/15 border border-accent/30 text-accent rounded-lg py-2.5 hover:bg-accent/25 transition">Run AI Optimization</button>
            <button onClick={() => navigate('/simulation')} className="text-xs bg-panel2 border border-border text-slate-300 rounded-lg py-2.5 hover:border-accent/40 transition">Run Simulation</button>
            <button onClick={() => navigate('/conflicts')} className="text-xs bg-panel2 border border-border text-slate-300 rounded-lg py-2.5 hover:border-accent/40 transition">Scan Conflicts</button>
            <button onClick={() => navigate('/analytics')} className="text-xs bg-panel2 border border-border text-slate-300 rounded-lg py-2.5 hover:border-accent/40 transition">View Analytics</button>
          </div>
        </div>
      </div>
    </Layout>
  )
}
