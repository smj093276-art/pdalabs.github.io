import React, { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import { api } from '../api/client'
import { Train, Station, Track, Conflict } from '../types'

const SCENARIOS = [
  { value: 'delay', label: 'Train Delay' },
  { value: 'track_block', label: 'Track Blockage' },
  { value: 'platform_unavailable', label: 'Platform Unavailable' },
  { value: 'congestion', label: 'Station Congestion' },
  { value: 'cancellation', label: 'Train Cancellation' },
]

export default function Simulation() {
  const [scenarioType, setScenarioType] = useState('delay')
  const [trains, setTrains] = useState<Train[]>([])
  const [stations, setStations] = useState<Station[]>([])
  const [tracks, setTracks] = useState<Track[]>([])
  const [trainNumber, setTrainNumber] = useState('')
  const [stationCode, setStationCode] = useState('')
  const [trackCode, setTrackCode] = useState('')
  const [magnitude, setMagnitude] = useState(25)
  const [running, setRunning] = useState(false)
  const [result, setResult] = useState<{ affected_trains: string[]; new_conflicts: Conflict[]; summary: string } | null>(null)
  const [history, setHistory] = useState<any[]>([])

  useEffect(() => {
    api.get('/trains').then((r) => setTrains(r.data))
    api.get('/stations').then((r) => setStations(r.data))
    api.get('/tracks').then((r) => setTracks(r.data))
    loadHistory()
  }, [])

  async function loadHistory() {
    const res = await api.get('/simulation/history')
    setHistory(res.data)
  }

  async function run() {
    setRunning(true)
    setResult(null)
    try {
      const payload: any = { scenario_type: scenarioType, magnitude_minutes: magnitude }
      if (scenarioType === 'delay' || scenarioType === 'cancellation') payload.train_number = trainNumber
      if (scenarioType === 'platform_unavailable' || scenarioType === 'congestion') payload.station_code = stationCode
      if (scenarioType === 'track_block') payload.track_code = trackCode

      const res = await api.post('/simulation/run', payload)
      setResult(res.data)
      loadHistory()
    } catch (e: any) {
      alert(e?.response?.data?.detail || 'Simulation failed')
    } finally {
      setRunning(false)
    }
  }

  return (
    <Layout title="Simulation" subtitle="Inject a disruption scenario, then detect its downstream conflicts">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-4">Create Scenario</h3>

          <label className="block text-xs text-slate-400 mb-1">Scenario Type</label>
          <select
            value={scenarioType} onChange={(e) => setScenarioType(e.target.value)}
            className="w-full bg-panel2 border border-border rounded-lg px-3 py-2 text-xs text-slate-200 mb-4 outline-none focus:border-accent"
          >
            {SCENARIOS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>

          {(scenarioType === 'delay' || scenarioType === 'cancellation') && (
            <>
              <label className="block text-xs text-slate-400 mb-1">Train</label>
              <select
                value={trainNumber} onChange={(e) => setTrainNumber(e.target.value)}
                className="w-full bg-panel2 border border-border rounded-lg px-3 py-2 text-xs text-slate-200 mb-4 outline-none focus:border-accent"
              >
                <option value="">Select a train…</option>
                {trains.map((t) => <option key={t.id} value={t.number}>{t.number} — {t.name}</option>)}
              </select>
            </>
          )}

          {(scenarioType === 'platform_unavailable' || scenarioType === 'congestion') && (
            <>
              <label className="block text-xs text-slate-400 mb-1">Station</label>
              <select
                value={stationCode} onChange={(e) => setStationCode(e.target.value)}
                className="w-full bg-panel2 border border-border rounded-lg px-3 py-2 text-xs text-slate-200 mb-4 outline-none focus:border-accent"
              >
                <option value="">Select a station…</option>
                {stations.map((s) => <option key={s.id} value={s.code}>{s.name} ({s.code})</option>)}
              </select>
            </>
          )}

          {scenarioType === 'track_block' && (
            <>
              <label className="block text-xs text-slate-400 mb-1">Track</label>
              <select
                value={trackCode} onChange={(e) => setTrackCode(e.target.value)}
                className="w-full bg-panel2 border border-border rounded-lg px-3 py-2 text-xs text-slate-200 mb-4 outline-none focus:border-accent"
              >
                <option value="">Select a track…</option>
                {tracks.map((t) => <option key={t.id} value={t.code}>{t.code}</option>)}
              </select>
            </>
          )}

          {scenarioType === 'delay' && (
            <>
              <label className="block text-xs text-slate-400 mb-1">Delay (minutes)</label>
              <input
                type="number" value={magnitude} onChange={(e) => setMagnitude(Number(e.target.value))}
                className="w-full bg-panel2 border border-border rounded-lg px-3 py-2 text-xs text-slate-200 mb-4 outline-none focus:border-accent"
              />
            </>
          )}

          <button
            onClick={run} disabled={running}
            className="w-full bg-accent hover:bg-accent/90 disabled:opacity-60 text-white text-xs font-medium rounded-lg py-2.5"
          >
            {running ? 'Running Simulation…' : 'Run Simulation'}
          </button>
        </div>

        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-4">Result</h3>
          {!result && <div className="text-xs text-slate-500">Run a scenario to see its impact here.</div>}
          {result && (
            <>
              <p className="text-xs text-slate-300 mb-3">{result.summary}</p>
              <div className="text-xs text-slate-400 mb-3">
                <span className="font-medium text-slate-300">Affected trains:</span>{' '}
                {result.affected_trains.length ? result.affected_trains.join(', ') : 'None'}
              </div>
              <div className="text-xs font-medium text-slate-300 mb-2">
                New/updated conflicts detected ({result.new_conflicts.length})
              </div>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {result.new_conflicts.map((c) => (
                  <div key={c.id} className="flex items-center justify-between text-xs bg-panel2 rounded-lg px-3 py-2 border border-border">
                    <span>{c.conflict_type}</span>
                    <span className={`badge ${c.severity === 'Critical' ? 'badge-crit' : 'badge-warn'}`}>{c.severity}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      <h3 className="text-sm font-semibold text-slate-200 mt-6 mb-3">Scenario History</h3>
      <div className="card overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-panel2 text-slate-500 text-left">
            <tr>
              <th className="px-3 py-2 font-medium">Time</th>
              <th className="px-3 py-2 font-medium">Scenario</th>
              <th className="px-3 py-2 font-medium">Summary</th>
            </tr>
          </thead>
          <tbody>
            {history.map((h) => (
              <tr key={h.id} className="border-t border-border">
                <td className="px-3 py-2 text-slate-400">{new Date(h.created_at).toLocaleString()}</td>
                <td className="px-3 py-2 text-slate-400">{h.scenario_type}</td>
                <td className="px-3 py-2 text-slate-400">{h.result_summary}</td>
              </tr>
            ))}
            {history.length === 0 && (
              <tr><td colSpan={3} className="px-3 py-6 text-center text-slate-500">No scenarios run yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </Layout>
  )
}
