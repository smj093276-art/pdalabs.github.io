import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!username.trim() || !password.trim()) {
      setError('Username and password are required.')
      return
    }
    setBusy(true)
    try {
      const user = await login(username.trim(), password)
      navigate(user.role === 'admin' ? '/admin' : '/dashboard')
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Login failed. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen bg-base flex items-center justify-center p-4">
      <div className="w-full max-w-4xl grid md:grid-cols-2 rounded-2xl overflow-hidden shadow-card border border-border">
        {/* Left brand panel */}
        <div className="hidden md:flex flex-col justify-between bg-gradient-to-br from-[#0b1730] to-[#0a0f1e] p-10 relative overflow-hidden">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg bg-accent/20 border border-accent/40 flex items-center justify-center text-accent font-bold">R</div>
              <span className="text-xl font-bold text-white">RAiLOPT <span className="text-accent">AI</span></span>
            </div>
            <p className="text-slate-400 mt-3 text-sm leading-relaxed">
              AI-Based Railway Traffic<br />Optimization &amp; Scheduling System
            </p>
          </div>
          <svg viewBox="0 0 300 140" className="w-full opacity-80">
            <rect x="10" y="70" width="220" height="40" rx="10" fill="#132038" stroke="#22314f" />
            <circle cx="40" cy="118" r="10" fill="#0f1729" stroke="#3b82f6" strokeWidth="3" />
            <circle cx="90" cy="118" r="10" fill="#0f1729" stroke="#3b82f6" strokeWidth="3" />
            <circle cx="150" cy="118" r="10" fill="#0f1729" stroke="#3b82f6" strokeWidth="3" />
            <circle cx="200" cy="118" r="10" fill="#0f1729" stroke="#3b82f6" strokeWidth="3" />
            <rect x="20" y="40" width="90" height="35" rx="8" fill="#16223d" stroke="#22314f" />
            {[...Array(4)].map((_, i) => (
              <rect key={i} x={30 + i * 20} y="48" width="12" height="14" rx="2" fill="#0ea5e9" opacity="0.7" />
            ))}
          </svg>
          <div className="text-xs text-slate-500">
            © 2025 AI-Based Railway Traffic Optimization &amp; Scheduling System
          </div>
        </div>

        {/* Right login form */}
        <div className="bg-panel p-8 md:p-10 flex flex-col justify-center">
          <h1 className="text-2xl font-bold text-white mb-1">Welcome Back</h1>
          <p className="text-slate-400 text-sm mb-6">Sign in to continue to the control center.</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Username</label>
              <input
                className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-accent transition"
                placeholder="Enter username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoFocus
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Password</label>
              <input
                type="password"
                className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-accent transition"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {error && (
              <div className="text-crit text-xs bg-crit/10 border border-crit/30 rounded-lg px-3 py-2">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full bg-accent hover:bg-accent/90 disabled:opacity-60 text-white font-medium rounded-lg py-2.5 text-sm transition"
            >
              {busy ? 'Signing in…' : 'LOGIN'}
            </button>
          </form>

          <div className="mt-6 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-ok" /> Simulation Environment
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-accent" /> System Operational
            </span>
          </div>

          <p className="text-[11px] text-slate-600 mt-6">
            Demo access: any username / any password. This is an academic simulation
            platform — not a live railway control system.
          </p>
        </div>
      </div>
    </div>
  )
}
