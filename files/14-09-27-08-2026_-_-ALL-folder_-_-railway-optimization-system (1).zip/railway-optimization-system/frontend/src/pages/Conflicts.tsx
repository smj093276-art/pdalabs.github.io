import React, { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import { api } from '../api/client'
import { Conflict, Train } from '../types'

export default function Conflicts() {
  const [conflicts, setConflicts] = useState<Conflict[]>([])
  const [trains, setTrains] = useState<Record<number, Train>>({})
  const [scanning, setScanning] = useState(false)

  async function load() {
    const [cf, tr] = await Promise.all([api.get('/conflicts'), api.get('/trains')])
    setConflicts(cf.data)
    const map: Record<number, Train> = {}
    tr.data.forEach((t: Train) => (map[t.id] = t))
    setTrains(map)
  }
  useEffect(() => { load() }, [])

  async function scan() {
    setScanning(true)
    try {
      const res = await api.post('/conflicts/scan')
      setConflicts(res.data)
    } finally {
      setScanning(false)
    }
  }

  async function resolve(id: number) {
    await api.post(`/conflicts/${id}/resolve`)
    load()
  }

  const active = conflicts.filter((c) => !c.resolved)
  const critical = active.filter((c) => c.severity === 'Critical').length
  const warning = active.filter((c) => c.severity === 'Warning').length

  return (
    <Layout title="Conflict Center" subtitle="Real conflict detection across tracks, platforms, schedules and station capacity">
      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-3">
          <div className="card px-4 py-2 text-xs">
            <span className="text-crit font-bold text-lg mr-1">{critical}</span> Critical
          </div>
          <div className="card px-4 py-2 text-xs">
            <span className="text-warn font-bold text-lg mr-1">{warning}</span> Warning
          </div>
        </div>
        <button
          onClick={scan} disabled={scanning}
          className="text-xs bg-accent hover:bg-accent/90 disabled:opacity-60 text-white rounded-lg px-4 py-2"
        >
          {scanning ? 'Scanning…' : 'Re-scan Network'}
        </button>
      </div>

      <div className="space-y-3">
        {active.map((c) => (
          <div key={c.id} className="card p-4 flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className={`badge ${c.severity === 'Critical' ? 'badge-crit' : 'badge-warn'}`}>{c.severity}</span>
                <span className="text-sm font-semibold text-slate-100">{c.conflict_type}</span>
              </div>
              <p className="text-xs text-slate-400">{c.description}</p>
              <p className="text-[11px] text-slate-600 mt-1">
                {trains[c.train_a_id]?.number}{c.train_b_id ? ` ↔ ${trains[c.train_b_id]?.number}` : ''} · detected {new Date(c.detected_at).toLocaleTimeString()}
              </p>
            </div>
            <button
              onClick={() => resolve(c.id)}
              className="text-xs bg-panel2 border border-border rounded-lg px-3 py-1.5 text-slate-300 hover:border-ok/40 hover:text-ok shrink-0"
            >
              Mark Resolved
            </button>
          </div>
        ))}
        {active.length === 0 && (
          <div className="card p-8 text-center text-xs text-slate-500">
            No active conflicts. Network is clean — try running a Simulation scenario to generate one.
          </div>
        )}
      </div>
    </Layout>
  )
}
