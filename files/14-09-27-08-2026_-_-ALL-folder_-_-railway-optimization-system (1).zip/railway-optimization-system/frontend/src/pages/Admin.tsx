import React, { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import KpiCard from '../components/KpiCard'
import { api } from '../api/client'

type Tab = 'overview' | 'stations' | 'trains' | 'users' | 'audit'

export default function Admin() {
  const [tab, setTab] = useState<Tab>('overview')
  const [stats, setStats] = useState<any>(null)
  const [stations, setStations] = useState<any[]>([])
  const [trains, setTrains] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [audit, setAudit] = useState<any[]>([])

  const [newStation, setNewStation] = useState({ code: '', name: '', zone: '', latitude: 0, longitude: 0, platform_count: 4, state: '' })
  const [newTrain, setNewTrain] = useState({ number: '', name: '', train_type: 'Express', priority: 3, origin_id: 0, destination_id: 0 })

  async function loadAll() {
    const [s, st, tr, us, au] = await Promise.all([
      api.get('/admin/stats'),
      api.get('/admin/stations'),
      api.get('/admin/trains'),
      api.get('/admin/users'),
      api.get('/admin/audit-logs'),
    ])
    setStats(s.data); setStations(st.data); setTrains(tr.data); setUsers(us.data); setAudit(au.data)
  }
  useEffect(() => { loadAll() }, [])

  async function createStation(e: React.FormEvent) {
    e.preventDefault()
    await api.post('/admin/stations', newStation)
    setNewStation({ code: '', name: '', zone: '', latitude: 0, longitude: 0, platform_count: 4, state: '' })
    loadAll()
  }

  async function deleteStation(id: number) {
    if (!confirm('Delete this station?')) return
    await api.delete(`/admin/stations/${id}`)
    loadAll()
  }

  async function createTrain(e: React.FormEvent) {
    e.preventDefault()
    await api.post('/admin/trains', newTrain)
    setNewTrain({ number: '', name: '', train_type: 'Express', priority: 3, origin_id: 0, destination_id: 0 })
    loadAll()
  }

  async function deleteTrain(id: number) {
    if (!confirm('Delete this train?')) return
    await api.delete(`/admin/trains/${id}`)
    loadAll()
  }

  async function toggleUser(id: number) {
    await api.post(`/admin/users/${id}/toggle-active`)
    loadAll()
  }

  const tabs: { key: Tab; label: string }[] = [
    { key: 'overview', label: 'Overview' },
    { key: 'stations', label: 'Stations' },
    { key: 'trains', label: 'Trains' },
    { key: 'users', label: 'Users' },
    { key: 'audit', label: 'Audit Log' },
  ]

  return (
    <Layout title="Admin Dashboard" subtitle="Hidden administrative control panel — visible to admin accounts only">
      <div className="flex gap-2 mb-5">
        {tabs.map((t) => (
          <button
            key={t.key} onClick={() => setTab(t.key)}
            className={`text-xs px-3 py-1.5 rounded-lg border ${tab === t.key ? 'bg-crit/15 border-crit/40 text-crit' : 'bg-panel2 border-border text-slate-400'}`}
          >{t.label}</button>
        ))}
      </div>

      {tab === 'overview' && stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <KpiCard label="Total Stations" value={stats.total_stations} />
          <KpiCard label="Total Trains" value={stats.total_trains} />
          <KpiCard label="Total Tracks" value={stats.total_tracks} />
          <KpiCard label="Total Platforms" value={stats.total_platforms} />
          <KpiCard label="Active Users" value={stats.active_users} />
          <KpiCard label="Optimization Runs" value={stats.optimization_runs} />
          <KpiCard label="Active Simulations" value={stats.active_simulations} />
          <KpiCard label="System Alerts" value={stats.system_alerts} tone={stats.system_alerts > 0 ? 'crit' : 'ok'} />
        </div>
      )}

      {tab === 'stations' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <form onSubmit={createStation} className="card p-4 space-y-2 text-xs">
            <h3 className="text-sm font-semibold text-slate-200 mb-2">Add Station</h3>
            <input required placeholder="Code (e.g. PUNE)" value={newStation.code} onChange={(e) => setNewStation({ ...newStation, code: e.target.value })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            <input required placeholder="Name" value={newStation.name} onChange={(e) => setNewStation({ ...newStation, name: e.target.value })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            <input placeholder="Zone" value={newStation.zone} onChange={(e) => setNewStation({ ...newStation, zone: e.target.value })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            <input placeholder="State" value={newStation.state} onChange={(e) => setNewStation({ ...newStation, state: e.target.value })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            <div className="flex gap-2">
              <input required type="number" step="any" placeholder="Latitude" value={newStation.latitude || ''} onChange={(e) => setNewStation({ ...newStation, latitude: Number(e.target.value) })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
              <input required type="number" step="any" placeholder="Longitude" value={newStation.longitude || ''} onChange={(e) => setNewStation({ ...newStation, longitude: Number(e.target.value) })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            </div>
            <input type="number" placeholder="Platforms" value={newStation.platform_count} onChange={(e) => setNewStation({ ...newStation, platform_count: Number(e.target.value) })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            <button className="w-full bg-accent text-white rounded-lg py-2 font-medium">Create Station</button>
          </form>

          <div className="lg:col-span-2 card overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-panel2 text-slate-500 text-left">
                <tr><th className="px-3 py-2">Code</th><th className="px-3 py-2">Name</th><th className="px-3 py-2">Platforms</th><th className="px-3 py-2"></th></tr>
              </thead>
              <tbody>
                {stations.map((s) => (
                  <tr key={s.id} className="border-t border-border">
                    <td className="px-3 py-2 text-slate-200">{s.code}</td>
                    <td className="px-3 py-2 text-slate-400">{s.name}</td>
                    <td className="px-3 py-2 text-slate-400">{s.platform_count}</td>
                    <td className="px-3 py-2 text-right"><button onClick={() => deleteStation(s.id)} className="text-crit hover:underline">Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'trains' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <form onSubmit={createTrain} className="card p-4 space-y-2 text-xs">
            <h3 className="text-sm font-semibold text-slate-200 mb-2">Add Train</h3>
            <input required placeholder="Train Number" value={newTrain.number} onChange={(e) => setNewTrain({ ...newTrain, number: e.target.value })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            <input required placeholder="Name" value={newTrain.name} onChange={(e) => setNewTrain({ ...newTrain, name: e.target.value })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            <select value={newTrain.train_type} onChange={(e) => setNewTrain({ ...newTrain, train_type: e.target.value })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2">
              {['Superfast', 'Express', 'Passenger', 'Freight', 'Suburban'].map((t) => <option key={t}>{t}</option>)}
            </select>
            <input type="number" min={1} max={5} placeholder="Priority (1=highest)" value={newTrain.priority} onChange={(e) => setNewTrain({ ...newTrain, priority: Number(e.target.value) })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2" />
            <select required value={newTrain.origin_id || ''} onChange={(e) => setNewTrain({ ...newTrain, origin_id: Number(e.target.value) })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2">
              <option value="">Origin station…</option>
              {stations.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.code})</option>)}
            </select>
            <select required value={newTrain.destination_id || ''} onChange={(e) => setNewTrain({ ...newTrain, destination_id: Number(e.target.value) })} className="w-full bg-panel2 border border-border rounded-lg px-3 py-2">
              <option value="">Destination station…</option>
              {stations.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.code})</option>)}
            </select>
            <button className="w-full bg-accent text-white rounded-lg py-2 font-medium">Create Train</button>
          </form>

          <div className="lg:col-span-2 card overflow-x-auto max-h-[520px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="bg-panel2 text-slate-500 text-left sticky top-0">
                <tr><th className="px-3 py-2">Number</th><th className="px-3 py-2">Name</th><th className="px-3 py-2">Type</th><th className="px-3 py-2"></th></tr>
              </thead>
              <tbody>
                {trains.map((t) => (
                  <tr key={t.id} className="border-t border-border">
                    <td className="px-3 py-2 text-slate-200">{t.number}</td>
                    <td className="px-3 py-2 text-slate-400">{t.name}</td>
                    <td className="px-3 py-2 text-slate-400">{t.train_type}</td>
                    <td className="px-3 py-2 text-right"><button onClick={() => deleteTrain(t.id)} className="text-crit hover:underline">Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'users' && (
        <div className="card overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-panel2 text-slate-500 text-left">
              <tr><th className="px-3 py-2">Username</th><th className="px-3 py-2">Role</th><th className="px-3 py-2">Status</th><th className="px-3 py-2"></th></tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-t border-border">
                  <td className="px-3 py-2 text-slate-200">{u.username}</td>
                  <td className="px-3 py-2 text-slate-400 capitalize">{u.role}</td>
                  <td className="px-3 py-2">
                    <span className={`badge ${u.is_active ? 'badge-ok' : 'badge-crit'}`}>{u.is_active ? 'Active' : 'Disabled'}</span>
                  </td>
                  <td className="px-3 py-2 text-right">
                    <button onClick={() => toggleUser(u.id)} className="text-accent hover:underline">
                      {u.is_active ? 'Disable' : 'Enable'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'audit' && (
        <div className="card overflow-x-auto max-h-[560px] overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="bg-panel2 text-slate-500 text-left sticky top-0">
              <tr><th className="px-3 py-2">Time</th><th className="px-3 py-2">User</th><th className="px-3 py-2">Action</th><th className="px-3 py-2">IP</th></tr>
            </thead>
            <tbody>
              {audit.map((a) => (
                <tr key={a.id} className="border-t border-border">
                  <td className="px-3 py-2 text-slate-400">{new Date(a.created_at).toLocaleString()}</td>
                  <td className="px-3 py-2 text-slate-200">{a.username}</td>
                  <td className="px-3 py-2 text-slate-400">{a.action}</td>
                  <td className="px-3 py-2 text-slate-500">{a.ip_address}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Layout>
  )
}
