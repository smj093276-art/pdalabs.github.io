import React, { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import { api } from '../api/client'
import { Station } from '../types'

interface PlatformRow {
  id: number
  station_code: string
  number: number
  is_occupied: boolean
  occupied_by_train_id: number | null
  under_maintenance: boolean
}

export default function Platforms() {
  const [stations, setStations] = useState<Station[]>([])
  const [stationCode, setStationCode] = useState<string>('')
  const [platforms, setPlatforms] = useState<PlatformRow[]>([])

  useEffect(() => {
    api.get('/stations').then((res) => {
      setStations(res.data)
      if (res.data.length) setStationCode(res.data[0].code)
    })
  }, [])

  useEffect(() => {
    if (!stationCode) return
    api.get('/platforms', { params: { station_code: stationCode } }).then((res) => setPlatforms(res.data))
  }, [stationCode])

  return (
    <Layout title="Platforms" subtitle="Platform occupancy and maintenance status per station">
      <div className="mb-4">
        <select
          value={stationCode} onChange={(e) => setStationCode(e.target.value)}
          className="bg-panel2 border border-border rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-accent"
        >
          {stations.map((s) => <option key={s.id} value={s.code}>{s.name} ({s.code})</option>)}
        </select>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
        {platforms.map((p) => (
          <div key={p.id} className={`card p-4 text-center border ${
            p.under_maintenance ? 'border-crit/40' : p.is_occupied ? 'border-warn/40' : 'border-ok/40'
          }`}>
            <div className="text-xs text-slate-500 mb-1">Platform</div>
            <div className="text-2xl font-bold text-slate-100 mb-2">{p.number}</div>
            {p.under_maintenance ? (
              <span className="badge badge-crit">Maintenance</span>
            ) : p.is_occupied ? (
              <span className="badge badge-warn">Occupied</span>
            ) : (
              <span className="badge badge-ok">Free</span>
            )}
          </div>
        ))}
        {platforms.length === 0 && <div className="text-xs text-slate-500 col-span-full">No platform data for this station.</div>}
      </div>
    </Layout>
  )
}
