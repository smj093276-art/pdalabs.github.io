import React, { useEffect, useState } from 'react'
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, LineChart, Line, Legend,
} from 'recharts'
import Layout from '../components/Layout'
import KpiCard from '../components/KpiCard'
import { api } from '../api/client'

const COLORS = ['#22c55e', '#f59e0b', '#ef4444']

export default function Analytics() {
  const [data, setData] = useState<any | null>(null)

  useEffect(() => {
    api.get('/analytics/overview').then((res) => setData(res.data))
  }, [])

  if (!data) {
    return <Layout title="Analytics"><div className="text-xs text-slate-500">Loading…</div></Layout>
  }

  const byType = Object.entries(data.by_train_type).map(([type, v]: any) => ({
    type, count: v.count, avgDelay: v.count ? +(v.total_delay / v.count).toFixed(1) : 0,
  }))

  const delayDist = Object.entries(data.delay_distribution).map(([name, value]: any) => ({ name, value }))

  return (
    <Layout title="Analytics" subtitle="Network performance trends and optimization impact">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <KpiCard label="Active Trains" value={data.summary.active_trains} />
        <KpiCard label="Punctuality" value={`${data.summary.network_punctuality}%`} tone="ok" />
        <KpiCard label="Platform Util." value={`${data.summary.platform_utilization}%`} />
        <KpiCard label="Track Util." value={`${data.summary.track_utilization}%`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        <div className="card p-4">
          <h3 className="text-sm font-semibold text-slate-200 mb-3">Trains &amp; Avg Delay by Type</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={byType}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="type" tick={{ fill: '#64748b', fontSize: 11 }} />
              <YAxis tick={{ fill: '#64748b', fontSize: 11 }} />
              <Tooltip contentStyle={{ background: '#131c33', border: '1px solid #1e293b', fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="count" name="Trains" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="avgDelay" name="Avg Delay (min)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card p-4">
          <h3 className="text-sm font-semibold text-slate-200 mb-3">Delay Distribution</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={delayDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>
                {delayDist.map((_: any, i: number) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: '#131c33', border: '1px solid #1e293b', fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-4">
          <h3 className="text-sm font-semibold text-slate-200 mb-3">Optimization Impact Over Time</h3>
          {data.optimization_trend.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={data.optimization_trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="run" tick={{ fill: '#64748b', fontSize: 11 }} />
                <YAxis tick={{ fill: '#64748b', fontSize: 11 }} />
                <Tooltip contentStyle={{ background: '#131c33', border: '1px solid #1e293b', fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="delay_before" name="Delay Before" stroke="#ef4444" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="delay_after" name="Delay After" stroke="#22c55e" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="text-xs text-slate-500 py-10 text-center">Run the AI Optimizer to see trend data.</div>
          )}
        </div>

        <div className="card p-4">
          <h3 className="text-sm font-semibold text-slate-200 mb-3">Top Delayed Trains</h3>
          <div className="space-y-2">
            {data.top_delayed_trains.map((t: any) => (
              <div key={t.number} className="flex items-center justify-between text-xs bg-panel2 rounded-lg px-3 py-2 border border-border">
                <span>{t.number} · {t.name}</span>
                <span className="text-warn font-medium">{t.delay_minutes}m</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}
