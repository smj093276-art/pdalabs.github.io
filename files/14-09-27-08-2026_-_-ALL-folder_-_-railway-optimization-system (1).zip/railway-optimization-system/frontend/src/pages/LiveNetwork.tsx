import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import Layout from '../components/Layout'
import RailwayMap from '../components/RailwayMap'
import { api } from '../api/client'
import { Station, StationDetail, Track, Train } from '../types'

function fmtTime(iso: string | null) {
  if (!iso) return '—'
  return new Date(iso).toLocaleString([], { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' })
}

function statusBadge(status: string) {
  if (status === 'On Time') return 'badge-ok'
  if (status === 'Delayed') return 'badge-warn'
  if (status === 'Critical Delay') return 'badge-crit'
  return 'badge-muted'
}

export default function LiveNetwork() {
  const [stations, setStations] = useState<Station[]>([])
  const [tracks, setTracks] = useState<Track[]>([])
  const [trains, setTrains] = useState<Train[]>([])
  const [stationDetail, setStationDetail] = useState<StationDetail | null>(null)
  const [stationTrains, setStationTrains] = useState<Train[]>([])
  const [selectedTrain, setSelectedTrain] = useState<Train | null>(null)
  const [params, setParams] = useSearchParams()

  async function loadBase() {
    const [st, tr, tn] = await Promise.all([api.get('/stations'), api.get('/tracks'), api.get('/trains')])
    setStations(st.data)
    setTracks(tr.data)
    setTrains(tn.data)
  }

  useEffect(() => { loadBase() }, [])

  async function selectStation(code: string) {
    setSelectedTrain(null)
    setParams({ station: code })
    const [detail, tns] = await Promise.all([
      api.get(`/stations/${code}`),
      api.get(`/stations/${code}/trains`),
    ])
    setStationDetail(detail.data)
    setStationTrains(tns.data)
  }

  async function selectTrain(number: string) {
    setStationDetail(null)
    setParams({ train: number })
    const res = await api.get(`/trains/${number}`)
    setSelectedTrain(res.data)
  }

  useEffect(() => {
    const st = params.get('station')
    const tn = params.get('train')
    if (st) selectStation(st)
    else if (tn) selectTrain(tn)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <Layout title="Live Network" subtitle="Click any station or train marker to inspect it">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 card p-3 h-[640px]">
          <RailwayMap
            stations={stations} tracks={tracks} trains={trains}
            onSelectStation={selectStation} onSelectTrain={selectTrain}
            selectedStationCode={stationDetail?.code}
          />
        </div>

        <div className="space-y-4">
          {stationDetail && (
            <div className="card p-4">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-sm font-bold text-slate-100">{stationDetail.name}</h2>
                <span className="badge badge-muted">{stationDetail.code}</span>
              </div>
              <p className="text-xs text-slate-500 mb-3">{stationDetail.zone} · {stationDetail.state}</p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <Stat label="Platforms" value={stationDetail.platform_count} />
                <Stat label="Available" value={stationDetail.available_platforms} />
                <Stat label="Incoming Trains" value={stationDetail.incoming_trains} />
                <Stat label="Outgoing Trains" value={stationDetail.outgoing_trains} />
                <Stat label="Track Utilization" value={`${stationDetail.track_utilization}%`} />
                <Stat label="Avg Delay" value={`${stationDetail.average_delay}m`} />
              </div>
              <div className="mt-2">
                <span className={`badge ${
                  stationDetail.congestion === 'High' ? 'badge-crit' :
                  stationDetail.congestion === 'Moderate' ? 'badge-warn' : 'badge-ok'
                }`}>
                  {stationDetail.congestion} Congestion
                </span>
              </div>

              <h3 className="text-xs font-semibold text-slate-300 mt-4 mb-2">Trains at this station</h3>
              <div className="space-y-1.5 max-h-48 overflow-y-auto">
                {stationTrains.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => selectTrain(t.number)}
                    className="w-full flex items-center justify-between text-xs bg-panel2 rounded-lg px-3 py-2 border border-border hover:border-accent/40 transition text-left"
                  >
                    <span>{t.number} · {t.name}</span>
                    <span className={`badge ${statusBadge(t.status)}`}>{t.status}</span>
                  </button>
                ))}
                {stationTrains.length === 0 && <div className="text-xs text-slate-500">No trains currently here.</div>}
              </div>
            </div>
          )}

          {selectedTrain && (
            <div className="card p-4">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-sm font-bold text-slate-100">{selectedTrain.number}</h2>
                <span className={`badge ${statusBadge(selectedTrain.status)}`}>{selectedTrain.status}</span>
              </div>
              <p className="text-xs text-slate-500 mb-3">{selectedTrain.name} · {selectedTrain.train_type} · Priority {selectedTrain.priority}</p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <Stat label="Delay" value={`${selectedTrain.delay_minutes}m`} />
                <Stat label="Platform" value={selectedTrain.platform_id ?? '—'} />
                <Stat label="Sched. Arrival" value={fmtTime(selectedTrain.scheduled_arrival)} />
                <Stat label="Est. Arrival" value={fmtTime(selectedTrain.estimated_arrival)} />
                <Stat label="Sched. Departure" value={fmtTime(selectedTrain.scheduled_departure)} />
                <Stat label="Est. Departure" value={fmtTime(selectedTrain.estimated_departure)} />
              </div>
            </div>
          )}

          {!stationDetail && !selectedTrain && (
            <div className="card p-6 text-center text-xs text-slate-500">
              Select a station or train on the map to see live details.
            </div>
          )}
        </div>
      </div>
    </Layout>
  )
}

function Stat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="bg-panel2 rounded-lg px-2.5 py-2 border border-border">
      <div className="text-[10px] text-slate-500">{label}</div>
      <div className="text-slate-200 font-medium">{value}</div>
    </div>
  )
}
