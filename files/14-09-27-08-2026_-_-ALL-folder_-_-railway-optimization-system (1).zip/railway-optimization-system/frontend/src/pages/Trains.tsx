import React, { useEffect, useMemo, useState } from 'react'
import Layout from '../components/Layout'
import { api } from '../api/client'
import { Train } from '../types'

function statusBadge(status: string) {
  if (status === 'On Time') return 'badge-ok'
  if (status === 'Delayed') return 'badge-warn'
  if (status === 'Critical Delay') return 'badge-crit'
  return 'badge-muted'
}

export default function Trains() {
  const [trains, setTrains] = useState<Train[]>([])
  const [query, setQuery] = useState('')
  const [typeFilter, setTypeFilter] = useState('All')
  const [selected, setSelected] = useState<Train | null>(null)
  const [route, setRoute] = useState<any[]>([])

  async function load() {
    const res = await api.get('/trains')
    setTrains(res.data)
  }
  useEffect(() => { load() }, [])

  const filtered = useMemo(() => {
    return trains.filter((t) => {
      const matchesQuery = query === '' ||
        t.number.toLowerCase().includes(query.toLowerCase()) ||
        t.name.toLowerCase().includes(query.toLowerCase())
      const matchesType = typeFilter === 'All' || t.train_type === typeFilter
      return matchesQuery && matchesType
    })
  }, [trains, query, typeFilter])

  async function openTrain(t: Train) {
    setSelected(t)
    const res = await api.get(`/trains/${t.number}/route`)
    setRoute(res.data)
  }

  return (
    <Layout title="Trains" subtitle={`${trains.length} trains in the simulated network`}>
      <div className="flex flex-wrap gap-2 mb-4">
        <input
          value={query} onChange={(e) => setQuery(e.target.value)}
          placeholder="Search train number or name…"
          className="bg-panel2 border border-border rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-accent w-64"
        />
        <select
          value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}
          className="bg-panel2 border border-border rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-accent"
        >
          {['All', 'Superfast', 'Express', 'Passenger', 'Freight', 'Suburban'].map((o) => (
            <option key={o} value={o}>{o}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 card overflow-hidden">
          <table className="w-full text-xs">
            <thead className="bg-panel2 text-slate-500 text-left">
              <tr>
                <th className="px-3 py-2 font-medium">Train</th>
                <th className="px-3 py-2 font-medium">Type</th>
                <th className="px-3 py-2 font-medium">Priority</th>
                <th className="px-3 py-2 font-medium">Delay</th>
                <th className="px-3 py-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((t) => (
                <tr
                  key={t.id}
                  onClick={() => openTrain(t)}
                  className={`border-t border-border cursor-pointer hover:bg-panel2/60 transition ${selected?.id === t.id ? 'bg-panel2' : ''}`}
                >
                  <td className="px-3 py-2">
                    <div className="font-medium text-slate-200">{t.number}</div>
                    <div className="text-slate-500">{t.name}</div>
                  </td>
                  <td className="px-3 py-2 text-slate-400">{t.train_type}</td>
                  <td className="px-3 py-2 text-slate-400">P{t.priority}</td>
                  <td className="px-3 py-2 text-slate-400">{t.delay_minutes}m</td>
                  <td className="px-3 py-2"><span className={`badge ${statusBadge(t.status)}`}>{t.status}</span></td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={5} className="px-3 py-6 text-center text-slate-500">No trains match your search.</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="card p-4">
          {!selected && <div className="text-xs text-slate-500">Select a train to view its route.</div>}
          {selected && (
            <>
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-sm font-bold text-slate-100">{selected.number}</h2>
                <span className={`badge ${statusBadge(selected.status)}`}>{selected.status}</span>
              </div>
              <p className="text-xs text-slate-500 mb-4">{selected.name} · {selected.train_type}</p>
              <h3 className="text-xs font-semibold text-slate-300 mb-2">Route</h3>
              <div className="space-y-2">
                {route.map((r, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <div className="w-2 h-2 rounded-full bg-accent shrink-0" />
                    <div>
                      <div className="text-slate-200 font-medium">{r.station_name} ({r.station_code})</div>
                      <div className="text-slate-500">
                        Arr: {r.original_arrival ? new Date(r.original_arrival).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
                        {r.platform_number ? ` · Platform ${r.platform_number}` : ''}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </Layout>
  )
}
