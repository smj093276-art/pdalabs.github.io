import React from 'react'

export default function KpiCard({
  label, value, sub, tone = 'default',
}: { label: string; value: React.ReactNode; sub?: string; tone?: 'default' | 'ok' | 'warn' | 'crit' }) {
  const toneColor = {
    default: 'text-slate-100',
    ok: 'text-ok',
    warn: 'text-warn',
    crit: 'text-crit',
  }[tone]

  return (
    <div className="card p-4">
      <div className="text-[11px] uppercase tracking-wide text-slate-500">{label}</div>
      <div className={`text-2xl font-bold mt-1 ${toneColor}`}>{value}</div>
      {sub && <div className="text-[11px] text-slate-500 mt-1">{sub}</div>}
    </div>
  )
}
