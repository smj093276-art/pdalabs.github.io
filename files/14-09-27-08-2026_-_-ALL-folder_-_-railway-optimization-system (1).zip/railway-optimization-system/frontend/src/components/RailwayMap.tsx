import React, { useMemo, useState } from 'react'
import { Station, Track, Train } from '../types'

const ROUTE_CODES: [string, string][] = [
  ['NDLS', 'UMB'], ['UMB', 'LDH'], ['LDH', 'CDG'], ['UMB', 'DDN'],
  ['NDLS', 'JP'], ['JP', 'JU'], ['JU', 'BKN'], ['NDLS', 'LKO'],
  ['LKO', 'BSB'], ['BSB', 'PNBE'], ['PNBE', 'GAYA'], ['GAYA', 'HWH'],
  ['PNBE', 'HWH'], ['NDLS', 'BPL'], ['BPL', 'JBP'], ['JBP', 'NGP'],
  ['BPL', 'ADI'], ['ADI', 'BDTS'], ['BDTS', 'ST'], ['ST', 'CSMT'],
  ['NGP', 'CSMT'], ['NGP', 'R'], ['R', 'BBS'], ['BBS', 'HWH'],
  ['NGP', 'BZA'], ['BZA', 'MAS'], ['MAS', 'SBC'], ['SBC', 'MYS'],
  ['SBC', 'UBL'], ['UBL', 'CSMT'], ['MAS', 'TVC'], ['SBC', 'TVC'],
  ['LKO', 'GHY'], ['HWH', 'GHY'],
]

const LON_MIN = 68, LON_MAX = 93, LAT_MIN = 8, LAT_MAX = 34
const W = 640, H = 620

function project(lat: number, lon: number) {
  const x = ((lon - LON_MIN) / (LON_MAX - LON_MIN)) * W
  const y = ((LAT_MAX - lat) / (LAT_MAX - LAT_MIN)) * H
  return { x, y }
}

function congestionColor(level: string) {
  if (level === 'High') return '#ef4444'
  if (level === 'Moderate') return '#f59e0b'
  return '#22c55e'
}

interface Props {
  stations: Station[]
  tracks: Track[]
  trains: Train[]
  onSelectStation?: (code: string) => void
  onSelectTrain?: (number: string) => void
  selectedStationCode?: string | null
}

export default function RailwayMap({ stations, tracks, trains, onSelectStation, onSelectTrain, selectedStationCode }: Props) {
  const [hover, setHover] = useState<Station | null>(null)

  const byCode = useMemo(() => {
    const m: Record<string, Station> = {}
    stations.forEach((s) => (m[s.code] = s))
    return m
  }, [stations])

  const byId = useMemo(() => {
    const m: Record<number, Station> = {}
    stations.forEach((s) => (m[s.id] = s))
    return m
  }, [stations])

  const trackCongestion = useMemo(() => {
    const m: Record<string, string> = {}
    tracks.forEach((t) => {
      const from = byId[t.from_station_id]?.code
      const to = byId[t.to_station_id]?.code
      if (from && to) m[`${from}-${to}`] = t.congestion
    })
    return m
  }, [tracks, byId])

  // place each active train at a pseudo-position along its current->next leg
  const trainMarkers = useMemo(() => {
    return trains
      .filter((t) => !t.is_cancelled)
      .map((t) => {
        const from = t.current_station_id ? byId[t.current_station_id] : null
        const to = t.next_station_id ? byId[t.next_station_id] : null
        if (!from || !to) return null
        const p1 = project(from.latitude, from.longitude)
        const p2 = project(to.latitude, to.longitude)
        // deterministic pseudo-progress from train id, so markers stay stable between renders
        const progress = 0.15 + ((t.id * 37) % 70) / 100
        const x = p1.x + (p2.x - p1.x) * progress
        const y = p1.y + (p2.y - p1.y) * progress
        const color = t.delay_minutes > 30 ? '#ef4444' : t.delay_minutes > 5 ? '#f59e0b' : '#22c55e'
        return { train: t, x, y, color }
      })
      .filter(Boolean) as { train: Train; x: number; y: number; color: string }[]
  }, [trains, byId])

  return (
    <div className="relative w-full h-full">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full">
        <defs>
          <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse">
            <path d="M 24 0 L 0 0 0 24" fill="none" stroke="#152238" strokeWidth="1" />
          </pattern>
          <radialGradient id="glow" cx="50%" cy="45%" r="65%">
            <stop offset="0%" stopColor="#0f2545" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#0a0f1e" stopOpacity="0" />
          </radialGradient>
        </defs>

        <rect width={W} height={H} fill="url(#glow)" />
        <rect width={W} height={H} fill="url(#grid)" opacity="0.5" />

        <text x="12" y="24" fill="#475569" fontSize="11" letterSpacing="2" fontWeight="600">
          SIMULATION NETWORK
        </text>

        {/* Routes */}
        {ROUTE_CODES.map(([a, b], i) => {
          const sa = byCode[a], sb = byCode[b]
          if (!sa || !sb) return null
          const pa = project(sa.latitude, sa.longitude)
          const pb = project(sb.latitude, sb.longitude)
          const congestion = trackCongestion[`${a}-${b}`] || trackCongestion[`${b}-${a}`] || 'Low'
          return (
            <line
              key={i}
              x1={pa.x} y1={pa.y} x2={pb.x} y2={pb.y}
              stroke={congestionColor(congestion)}
              strokeOpacity={congestion === 'Low' ? 0.25 : 0.55}
              strokeWidth={congestion === 'High' ? 2 : 1.2}
            />
          )
        })}

        {/* Trains */}
        {trainMarkers.map(({ train, x, y, color }) => (
          <g
            key={train.id}
            className="cursor-pointer"
            onClick={() => onSelectTrain?.(train.number)}
          >
            <circle cx={x} cy={y} r={4} fill={color} stroke="#0a0f1e" strokeWidth={1.5}>
              <title>{`${train.number} — ${train.name} (${train.status})`}</title>
            </circle>
          </g>
        ))}

        {/* Stations */}
        {stations.map((s) => {
          const p = project(s.latitude, s.longitude)
          const selected = s.code === selectedStationCode
          return (
            <g
              key={s.id}
              className="cursor-pointer"
              onMouseEnter={() => setHover(s)}
              onMouseLeave={() => setHover(null)}
              onClick={() => onSelectStation?.(s.code)}
            >
              <circle cx={p.x} cy={p.y} r={selected ? 7 : 5} fill="#0f1729" stroke={selected ? '#38bdf8' : '#3b82f6'} strokeWidth={selected ? 2.5 : 1.8} />
              <circle cx={p.x} cy={p.y} r={1.6} fill="#3b82f6" />
              <text x={p.x + 8} y={p.y + 3} fontSize="9" fill="#94a3b8">{s.code}</text>
            </g>
          )
        })}
      </svg>

      {hover && (
        <div
          className="absolute pointer-events-none bg-panel2 border border-border rounded-lg px-3 py-2 text-xs shadow-card"
          style={{ left: 12, bottom: 12 }}
        >
          <div className="font-semibold text-slate-100">{hover.name} ({hover.code})</div>
          <div className="text-slate-500">{hover.state} · {hover.platform_count} platforms</div>
        </div>
      )}

      <div className="absolute top-2 right-2 bg-panel2/90 border border-border rounded-lg px-3 py-2 text-[10px] space-y-1">
        <div className="font-semibold text-slate-400 mb-1">LEGEND</div>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-ok" /> On Time</div>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-warn" /> Delayed</div>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-crit" /> Critical Delay</div>
      </div>
    </div>
  )
}
