import React from 'react'
import { NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: '◧' },
  { to: '/live-network', label: 'Live Network', icon: '◎' },
  { to: '/trains', label: 'Trains', icon: '🚆' },
  { to: '/schedules', label: 'Schedules', icon: '🕒' },
  { to: '/platforms', label: 'Platforms', icon: '▤' },
  { to: '/tracks', label: 'Tracks', icon: '⛯' },
  { to: '/conflicts', label: 'Conflicts', icon: '⚠' },
  { to: '/optimizer', label: 'AI Optimizer', icon: '⚙' },
  { to: '/simulation', label: 'Simulation', icon: '▶' },
  { to: '/analytics', label: 'Analytics', icon: '📈' },
]

export default function Sidebar() {
  const { user, logout } = useAuth()

  return (
    <div className="w-56 shrink-0 bg-panel border-r border-border h-screen sticky top-0 flex flex-col">
      <div className="px-4 py-4 flex items-center gap-2 border-b border-border">
        <div className="w-8 h-8 rounded-lg bg-accent/20 border border-accent/40 flex items-center justify-center text-accent font-bold text-sm">R</div>
        <span className="font-bold text-white text-sm">RAiLOPT <span className="text-accent">AI</span></span>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition ${
                isActive
                  ? 'bg-accent/15 text-accent border border-accent/30'
                  : 'text-slate-400 hover:bg-panel2 hover:text-slate-200 border border-transparent'
              }`
            }
          >
            <span className="text-xs w-4 text-center">{item.icon}</span>
            {item.label}
          </NavLink>
        ))}

        {user?.role === 'admin' && (
          <NavLink
            to="/admin"
            className={({ isActive }) =>
              `mt-2 flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition ${
                isActive
                  ? 'bg-crit/15 text-crit border border-crit/30'
                  : 'text-crit/80 hover:bg-crit/10 border border-transparent'
              }`
            }
          >
            <span className="text-xs w-4 text-center">🛡</span>
            Admin Panel
          </NavLink>
        )}
      </nav>

      <div className="p-3 border-t border-border">
        <div className="flex items-center gap-2 px-1 py-2">
          <div className="w-7 h-7 rounded-full bg-accent/20 flex items-center justify-center text-xs font-semibold text-accent">
            {user?.username?.[0]?.toUpperCase() ?? '?'}
          </div>
          <div className="min-w-0">
            <div className="text-xs font-medium text-slate-200 truncate">{user?.username}</div>
            <div className="text-[10px] text-slate-500 capitalize">{user?.role}</div>
          </div>
        </div>
        <button
          onClick={logout}
          className="w-full mt-1 text-xs text-slate-400 hover:text-crit border border-border hover:border-crit/40 rounded-lg py-1.5 transition"
        >
          Logout
        </button>
      </div>
    </div>
  )
}
