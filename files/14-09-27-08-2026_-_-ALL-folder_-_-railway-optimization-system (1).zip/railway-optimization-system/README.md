# AI-Based Railway Traffic Optimization & Scheduling System

A full-stack academic simulation platform for railway traffic monitoring, conflict
detection and AI-based schedule optimization. **This is a simulation system, not a
real railway control system.**

## Tech stack

| Layer      | Technology |
|------------|------------|
| Frontend   | React + TypeScript + Vite, Tailwind CSS, Recharts |
| Backend    | Python FastAPI |
| Database   | SQLite (default, zero-config) — swap to PostgreSQL by setting `DATABASE_URL` |
| ORM        | SQLAlchemy |
| Auth       | JWT (python-jose) + bcrypt password hashing (passlib) |

The spec called for PostgreSQL; SQLAlchemy makes that a one-line change
(`DATABASE_URL=postgresql+psycopg2://user:pass@host:5432/railway_db`) with **no code
changes**. SQLite ships by default so the project runs immediately with zero database
setup — convenient for a final-year project demo/viva.

## Running it

You need Python 3.10+ and Node.js 18+ installed, with internet access for the one-time
package installs (this project was authored in a sandboxed environment with no network
access, so the code has been written carefully and syntax-checked, but hasn't been
executed end-to-end — run it locally and see "Known limitations" below for what to
watch for first).

### 1. Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

(or just run `./run.sh` on macOS/Linux, which does the above for you)

The first startup automatically creates `railway.db` (SQLite) and seeds it with a
realistic simulated Indian railway network — 29 stations, ~68 track segments, 24
trains, platforms, two users. API docs: http://localhost:8000/docs

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173 — Vite proxies `/api` to the backend on port 8000.

### Login

- **Normal user:** any non-empty username + any non-empty password (e.g. `Rahul` /
  `1234`). First login for a new username auto-provisions that account.
- **Hidden admin:** username `SAMPATHRAJ`, password `128`. Not shown anywhere in the
  UI — there is no role selector on the login page. The Admin Panel link in the
  sidebar only renders for the admin role, and every `/api/admin/*` endpoint is
  independently protected server-side (`require_admin` dependency), so a normal user
  cannot reach admin data even by calling the API directly.

## What's implemented

1. **Dashboard** — live KPIs (active/delayed trains, conflicts, utilization,
   punctuality), map preview, active alerts, AI recommendation summary, quick actions.
2. **Interactive railway map** (`/live-network`) — SVG map of the simulated Indian
   network, projected from real station lat/lon. Click a station or train to see live
   details in the side panel. Route/congestion coloring is live from track data.
3. **Stations** — accessed via the map; shows platforms, availability, incoming/
   outgoing trains, congestion, track utilization, average delay — all computed from
   live train data, not hardcoded.
4. **Trains** — searchable/filterable list, click-through to full route with per-station
   arrival/departure and platform.
5. **Schedules** — original vs AI-optimized timetable, toggle + CSV export.
6. **Platforms & Tracks** — live occupancy/maintenance status per station; track list
   with congestion and blockage status.
7. **Conflict detection** (`app/conflicts.py`) — a real rule engine, not hardcoded
   data. It detects track conflicts, platform conflicts, schedule overlaps,
   insufficient headway, and station capacity conflicts by comparing actual train
   time windows and shared resources.
8. **AI Optimizer** (`app/optimizer.py`) — a priority-weighted greedy constraint
   scheduler. Ranks trains by priority class, train type and existing delay; resolves
   conflicts by shifting the lower-urgency train just enough to clear the conflict
   plus a mandatory safety headway (a hard constraint that's never violated). Shows
   before/after delay, conflicts, and punctuality, plus a plain-language explanation
   of what it did and why.
9. **Simulation** — inject delay, track blockage, platform unavailability, station
   congestion, or cancellation scenarios; the conflict engine then re-scans and shows
   exactly what broke.
10. **Analytics** — trains & delay by type, delay distribution, optimization impact
    trend, top delayed trains (Recharts).
11. **Hidden Admin Panel** — stats, station/train CRUD, user management (enable/
    disable), audit log. Gated both by frontend routing and backend dependency
    injection.

## Database entities

Users, Stations, Platforms, Tracks, Trains, ScheduleEntry, Conflict,
OptimizationResult, SimulationScenario, Notification, AuditLog — see
`backend/app/models.py`.

## Project structure

```
railway-optimization-system/
  backend/
    app/
      main.py            FastAPI app + router wiring
      database.py         SQLAlchemy engine/session
      models.py           ORM models (all entities)
      schemas.py           Pydantic request/response schemas
      auth.py               JWT + password hashing + role gate
      conflicts.py           Real conflict detection engine
      optimizer.py            AI optimization engine
      seed.py                  Simulated network seed data
      routers/                 One router per feature area
    requirements.txt
    run.sh
  frontend/
    src/
      pages/            One component per sidebar feature
      components/         Sidebar, Topbar, Layout, RailwayMap, KpiCard, ProtectedRoute
      context/AuthContext.tsx
      api/client.ts        Axios instance with JWT interceptor
      types/                Shared TS interfaces
    package.json
    vite.config.ts
    tailwind.config.js
```

## Known limitations / things to verify on first run

Built in a network-isolated sandbox, so `pip install` / `npm install` and actual
execution couldn't be tested here. Everything was written carefully and every Python
file passed `py_compile`, but on first run, watch for:

- **passlib/bcrypt version quirk**: some `passlib`+`bcrypt` combinations emit a
  harmless warning about `__about__`. If login hashing errors instead of just
  warning, pin `bcrypt==4.0.1` in `requirements.txt`.
- **SQLite datetime handling**: SQLAlchemy stores naive UTC datetimes; this is
  consistent throughout the codebase, but if you switch to PostgreSQL, timezone-aware
  columns behave slightly differently — not expected to break anything, but worth a
  smoke test.
- After the very first `npm install`, run `npm run build` once to let TypeScript
  surface any strict-mode issues before you rely on `npm run dev` alone.

Please run both servers, click through each sidebar item, and file/fix anything that
surfaces — the architecture is complete and the logic is real (no fake buttons, no
hardcoded "AI" results), but a first real run is the last mile.
